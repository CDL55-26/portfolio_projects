`timescale 1ns / 1ps
module i2c_controller #(
    parameter integer PRESCALE       = 16'd250,
    parameter         STOP_ON_IDLE   = 1
)(
    input              start,
    input  wire        clk,
    input  wire        rst,

    output reg  [23:0] sample_red_out,
    output reg  [23:0] sample_ir_out,

    output wire [15:0] controller_LED,

    inout  wire        i2c_scl,
    inout  wire        i2c_sda
);

    // ------------------------------------------------------------------------
    // IOBUF Setup
    // ------------------------------------------------------------------------
    wire scl_o, scl_t, scl_i;
    wire sda_o, sda_t, sda_i;

    IOBUF scl_buf (
        .IO  (i2c_scl),
        .I   (scl_o),
        .T   (scl_t),
        .O   (scl_i)
    );

    IOBUF sda_buf (
        .IO  (i2c_sda),
        .I   (sda_o),
        .T   (sda_t),
        .O   (sda_i)
    );

    // ------------------------------------------------------------------------
    // Signals to/from i2c_master
    // ------------------------------------------------------------------------
    reg  [6:0]  ctrl_cmd_address;
    reg         ctrl_cmd_start, ctrl_cmd_stop, ctrl_cmd_read, ctrl_cmd_write, ctrl_cmd_write_multiple;
    reg         ctrl_cmd_valid;
    wire        i2cm_cmd_ready;

    reg  [7:0]  ctrl_data_tdata;
    reg         ctrl_data_tvalid, ctrl_data_tlast;
    wire        i2cm_data_tready;

    wire [7:0]  i2cm_data_tdata;
    wire        i2cm_data_tvalid, i2cm_data_tlast;
    reg         ctrl_data_tready;

    // ------------------------------------------------------------------------
    // i2c_master instantiation
    // ------------------------------------------------------------------------
    i2c_master i2c_m (
        .clk                  (clk),    // O: system clock
        .rst                  (rst),    // O: synchronous reset

        .s_axis_cmd_address   (ctrl_cmd_address),   // O: 7-bit I2C slave address
        .s_axis_cmd_start     (ctrl_cmd_start),     // O: assert to send START
        .s_axis_cmd_read      (ctrl_cmd_read),      // O: assert to read
        .s_axis_cmd_write     (ctrl_cmd_write),     // O: assert to write one byte
        .s_axis_cmd_write_multiple (ctrl_cmd_write_multiple),  // O: assert to write multiple bytes
        .s_axis_cmd_stop      (ctrl_cmd_stop),      // O: assert to send STOP
        .s_axis_cmd_valid     (ctrl_cmd_valid),     // O: assert when command is valid
        .s_axis_cmd_ready     (i2cm_cmd_ready),     // I: high when command is accepted

        .s_axis_data_tdata    (ctrl_data_tdata),    // O: byte to write
        .s_axis_data_tvalid   (ctrl_data_tvalid),   // O: assert when write byte is valid
        .s_axis_data_tready   (i2cm_data_tready),   // I: high when ready for byte
        .s_axis_data_tlast    (ctrl_data_tlast),    // O: assert with final byte

        .m_axis_data_tdata    (i2cm_data_tdata),    // I: byte read from slave
        .m_axis_data_tvalid   (i2cm_data_tvalid),   // I: high when read byte is valid
        .m_axis_data_tready   (ctrl_data_tready),   // O: assert to accept read byte
        .m_axis_data_tlast    (i2cm_data_tlast),    // I: high with final read byte

        .scl_i                (scl_i),       // I: input from SCL pin
        .scl_o                (scl_o),       // O: drives SCL low
        .scl_t                (scl_t),       // O: tristate control for SCL
        .sda_i                (sda_i),       // I: input from SDA pin
        .sda_o                (sda_o),       // O: drives SDA low
        .sda_t                (sda_t),       // O: tristate control for SDA

        .prescale             (PRESCALE),           // O: clock divider for SCL speed
        .stop_on_idle         (STOP_ON_IDLE)        // O: auto STOP if idle
    );

    // ------------------------------------------------------------------------
    // FSM States
    // ------------------------------------------------------------------------
    localparam [4:0] IDLE              = 5'd0,
                     START_TRANSAC     = 5'd1,
                     WRITE_ADDRESS     = 5'd2,
                     WRITE_DATA        = 5'd3,
                     END_TRANSAC       = 5'd4,
                     RESTART_TRANSAC   = 5'd5,
                     STALL             = 5'd6;

    reg [4:0] state;

    // ROM Block
    localparam [6:0] MAX30102_ADDR = 7'h57;
    localparam [7:0] FIFO_DATA_REG = 8'h07; // TODO -> need to write to FIFO then restart

    reg [2:0] config_index;

    localparam [7:0] REG_MODE_CONFIG        = 8'h09;
    localparam [7:0] REG_SPO2_CONFIG        = 8'h0A;
    localparam [7:0] REG_LED1_PA            = 8'h0C;
    localparam [7:0] REG_LED2_PA            = 8'h0D;
    localparam [7:0] FIFO_CFG_ROLLOVER      = 8'h08;

    localparam [7:0] MODE_SPO2_EN               = 8'h03;
    localparam [7:0] SPO2_CFG_16UA_100SPS_18BIT = 8'hC7;
    localparam [7:0] LED_CURRENT_25MA           = 8'h7F;
    localparam [7:0] FIFO_CFG_ROLLOVER_NOINT    = 8'h10;

    localparam CONFIG_TABLE_SIZE = 5;
    reg [7:0] config_register_addr [0:CONFIG_TABLE_SIZE-1];
    reg [7:0] config_register_data [0:CONFIG_TABLE_SIZE-1];
    initial begin
        config_register_addr[0] = REG_MODE_CONFIG;       config_register_data[0] = MODE_SPO2_EN;
        config_register_addr[1] = REG_SPO2_CONFIG;       config_register_data[1] = SPO2_CFG_16UA_100SPS_18BIT;
        config_register_addr[2] = REG_LED1_PA;           config_register_data[2] = LED_CURRENT_25MA;
        config_register_addr[3] = REG_LED2_PA;           config_register_data[3] = LED_CURRENT_25MA;
        config_register_addr[4] = FIFO_CFG_ROLLOVER;     config_register_data[4] = FIFO_CFG_ROLLOVER_NOINT;
        //config_register_addr[5] = FIFO_DATA_REG; //do not delete, this is meant to be last write before restart
    end

    // ------------------------------------------------------------------------
    // Sequential FSM Logic
    // ------------------------------------------------------------------------
    // Sequential FSM Logic
always @(posedge clk or posedge rst) begin
    if (rst) begin
        ctrl_cmd_valid         <= 0;
        ctrl_cmd_start         <= 0;
        ctrl_cmd_write         <= 0;
        ctrl_cmd_write_multiple <= 0;
        ctrl_cmd_read          <= 0;
        ctrl_cmd_stop          <= 0;
        ctrl_cmd_address       <= 0;

        ctrl_data_tdata        <= 0;
        ctrl_data_tvalid       <= 0;
        ctrl_data_tlast        <= 0;
        ctrl_data_tready       <= 0;

        config_index           <= 0;
        state                  <= IDLE;
    end 
    else begin
        // Default: maintain current values unless explicitly changed
        // Only clear one-shot signals
        ctrl_cmd_valid         <= 0;
        
        // Handle reading data from the master
        if (i2cm_data_tvalid) begin
            ctrl_data_tready <= 1;
        end else begin
            ctrl_data_tready <= 0;
        end

        case (state)
            IDLE: begin
                // Clear all command signals in IDLE
                ctrl_cmd_start         <= 0;
                ctrl_cmd_write         <= 0;
                ctrl_cmd_write_multiple <= 0;
                ctrl_cmd_read          <= 0;
                ctrl_cmd_stop          <= 0;
                ctrl_data_tvalid       <= 0;
                ctrl_data_tlast        <= 0;
                
                if (start) begin
                    state <= START_TRANSAC;
                end
            end

            START_TRANSAC: begin
                // Prepare command signals
                ctrl_cmd_start   <= 1;
                ctrl_cmd_write   <= 0;
                ctrl_cmd_write_multiple <= 1;
                ctrl_cmd_stop    <= 0;
                ctrl_cmd_address <= MAX30102_ADDR;
                
                // Assert valid only when all signals are set up
                ctrl_cmd_valid   <= 1;
                
                // Wait for master to accept command
                if (ctrl_cmd_valid && i2cm_cmd_ready) begin
                    // Move to next state once master accepts the command
                    ctrl_cmd_valid <= 0;
                    ctrl_cmd_start <= 0;
                    ctrl_cmd_write_multiple <= 0;
                    state <= WRITE_ADDRESS;
                end
            end

            WRITE_ADDRESS: begin
                // Setup register address to write
                ctrl_data_tdata  <= config_register_addr[config_index];
                ctrl_data_tvalid <= 1;
                ctrl_data_tlast  <= 0; // Not the last byte
                
                // Wait for master to accept the data
                if (ctrl_data_tvalid && i2cm_data_tready) begin
                    // Clear valid once data is accepted
                    ctrl_data_tvalid <= 0;
                    state <= WRITE_DATA;
                end
            end

            WRITE_DATA: begin
                // Setup register data to write
                ctrl_data_tdata  <= config_register_data[config_index];
                ctrl_data_tvalid <= 1;
                ctrl_data_tlast  <= 1; // Last byte of current transaction
                
                // Wait for master to accept the data
                if (ctrl_data_tvalid && i2cm_data_tready) begin
                    // Clear valid once data is accepted
                    ctrl_data_tvalid <= 0;
                    state <= END_TRANSAC;
                end
            end

            END_TRANSAC: begin
                // Issue STOP condition
                ctrl_cmd_stop    <= 1;
                ctrl_cmd_valid   <= 1;
                
                // Wait for master to accept the command
                if (ctrl_cmd_valid && i2cm_cmd_ready) begin
                    // Clear signals once command is accepted
                    ctrl_cmd_valid <= 0;
                    ctrl_cmd_stop  <= 0;
                    
                    if (config_index == CONFIG_TABLE_SIZE - 1) begin
                        state <= STALL;
                    end else begin
                        config_index <= config_index + 1;
                        state <= START_TRANSAC;
                    end
                end
            end

            RESTART_TRANSAC: begin
                // This state isn't used in current implementation
                // But keeping it for future expansion
                state <= START_TRANSAC;
            end

            STALL: begin
                // Do nothing, prevent issues with button bouncing
            end
            
            default: state <= IDLE;
        endcase
    end
end

assign controller_LED[5:0] = state;
assign controller_LED[15:6] = 10'b0;

endmodule