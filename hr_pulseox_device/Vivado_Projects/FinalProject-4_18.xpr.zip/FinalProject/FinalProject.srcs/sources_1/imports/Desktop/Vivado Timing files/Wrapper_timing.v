`timescale 1ns / 1ps
module Wrapper_timing (
    input  wire        clk_100mhz,
    input  wire        reset_rtl_0,
    input  wire        start_0,

    output wire [15:0] LED,

    inout  wire        scl, //scl line ***NEED to make sure that these are configured properly for vivado
    inout  wire        sda  //sda line 
);

    wire clk25, pll_locked;
    clk_wiz_0 u_clk_wiz ( //clock wizzard module, 100mhz -> 25 mhz
        .clk_in1  (clk_100mhz),
        .reset    (reset_rtl_0),
        .clk_out1 (clk25),
        .locked   (pll_locked)
    );

    reg [3:0] rst_sync = 4'hF;
    always @(posedge clk25 or posedge reset_rtl_0) begin //reset logic to make sure clock wizzard doesnt bug
        if (reset_rtl_0)      rst_sync <= 4'hF;
        else if (!pll_locked) rst_sync <= {rst_sync[2:0], 1'b1};
        else                  rst_sync <= {rst_sync[2:0], 1'b0};
    end

    wire reset   = rst_sync[3];;
    wire reset_n = ~reset;

    localparam MMREG      = 5'd9; //Reg to write start signal for CPU
    localparam INSTR_FILE = "";

	//Processor instantiation
    wire         rwe, mwe;
    wire  [4:0]  rd, rs1, rs2;
    wire [31:0]  instAddr, instData;
    wire [31:0]  rData, regA, regB;
    wire [31:0]  memAddr, memDataIn, memDataOut;

    processor CPU (
        .clock            (clk25),
        .reset            (reset),
        .address_imem     (instAddr),
        .q_imem           (instData),
        .ctrl_writeEnable (rwe),
        .ctrl_writeReg    (rd),
        .ctrl_readRegA    (rs1),
        .ctrl_readRegB    (rs2),
        .data_writeReg    (rData),
        .data_readRegA    (regA),
        .data_readRegB    (regB),
        .wren             (mwe),
        .address_dmem     (memAddr),
        .data             (memDataIn),
        .q_dmem           (memDataOut)
    );

	//Instruction ROM
    ROM #(.MEMFILE({INSTR_FILE,".mem"})) InstMem (
        .clk     (clk25),
        .addr    (instAddr[11:0]),
        .dataOut (instData)
    );
	//Regifile
    regfile RegisterFile (
        .clock            (clk25),
        .ctrl_writeEnable (data_ready ? 1'b1 : rwe), //if data_ready flag high, enable Reg write
        .ctrl_reset       (reset),
        .ctrl_writeReg    (data_ready ? MMREG : rd), //Choose reg 9 for start signal
        .ctrl_readRegA    (rs1),
        .ctrl_readRegB    (rs2),
        .data_writeReg    (data_ready ? 32'd1 : rData), //send a 1 to reg 9
        .data_readRegA    (regA),
        .data_readRegB    (regB)
    );

	//RAM module
    RAM ProcMem (
        .clk    (clk25),
        .wEn    (interface_busy ? interface_ram_we : mwe), //if interface busy, sampling data, take controller RAM control, not CPU
        .addr   (interface_busy ? interface_ram_addr : memAddr[11:0]),
        .dataIn (interface_busy ? interface_ram_data : memDataIn),
        .dataOut(memDataOut)
    );

    wire        interface_busy, data_ready;
    wire [11:0] interface_ram_addr;
    wire [31:0] interface_ram_data;
    wire        interface_ram_we;
    wire [15:0] interface_LED;

    wire [31:0] s_axi_awaddr, s_axi_wdata, s_axi_araddr;
    wire        s_axi_awvalid, s_axi_wvalid, s_axi_arvalid;
    wire        s_axi_awready, s_axi_wready, s_axi_arready;
    wire [1:0]  s_axi_bresp, s_axi_rresp;
    wire        s_axi_bvalid, s_axi_bready, s_axi_rvalid, s_axi_rready;
    wire [31:0] s_axi_rdata;

	//AXI-lite -> I2C controller
    max30102_axi_controller #(
        .C_S_AXI_ADDR_WIDTH(32),
        .C_S_AXI_DATA_WIDTH(32),
        .IIC_BASE_ADDR     (32'h0000_0000),
        .ADDR_WIDTH        (12),
        .DATA_WIDTH        (32),
        .NUM_SAMPLES       (1000)
    ) controller (
        .clk                (clk25),
        .rst                (reset),
        .start              (start_0),
        .is_busy            (interface_busy),
        .data_ready         (data_ready),
        .ram_write_addr     (interface_ram_addr),
        .ram_write_data     (interface_ram_data),
        .ram_write_enable   (interface_ram_we),
        .debug_leds         (interface_LED),
        .axi_awaddr         (s_axi_awaddr),
        .axi_awvalid        (s_axi_awvalid),
        .axi_awready        (s_axi_awready),
        .axi_wdata          (s_axi_wdata),
        .axi_wvalid         (s_axi_wvalid),
        .axi_wready         (s_axi_wready),
        .axi_bresp          (s_axi_bresp),
        .axi_bvalid         (s_axi_bvalid),
        .axi_bready         (s_axi_bready),
        .axi_araddr         (s_axi_araddr),
        .axi_arvalid        (s_axi_arvalid),
        .axi_arready        (s_axi_arready),
        .axi_rdata          (s_axi_rdata),
        .axi_rresp          (s_axi_rresp),
        .axi_rvalid         (s_axi_rvalid),
        .axi_rready         (s_axi_rready)
    );

    wire [8:0] iic_awaddr = s_axi_awaddr[8:0];
    wire [8:0] iic_araddr = s_axi_araddr[8:0];

    wire axi_iic_0_scl_i, axi_iic_0_scl_o, axi_iic_0_scl_t;
    wire axi_iic_0_sda_i, axi_iic_0_sda_o, axi_iic_0_sda_t;

	//vivado AXI core 
    axi_iic_0 iic_core (
        .s_axi_aclk    (clk25),
        .s_axi_aresetn (reset_n),
        .s_axi_awaddr  (iic_awaddr),
        .s_axi_awvalid (s_axi_awvalid),
        .s_axi_awready (s_axi_awready),
        .s_axi_wdata   (s_axi_wdata),
        .s_axi_wvalid  (s_axi_wvalid),
        .s_axi_wready  (s_axi_wready),
        .s_axi_bresp   (s_axi_bresp),
        .s_axi_bvalid  (s_axi_bvalid),
        .s_axi_bready  (s_axi_bready),
        .s_axi_araddr  (iic_araddr),
        .s_axi_arvalid (s_axi_arvalid),
        .s_axi_arready (s_axi_arready),
        .s_axi_rdata   (s_axi_rdata),
        .s_axi_rresp   (s_axi_rresp),
        .s_axi_rvalid  (s_axi_rvalid),
        .s_axi_rready  (s_axi_rready),
        .scl_i (axi_iic_0_scl_i),
        .scl_o (axi_iic_0_scl_o),
        .scl_t (axi_iic_0_scl_t),
        .sda_i (axi_iic_0_sda_i),
        .sda_o (axi_iic_0_sda_o),
        .sda_t (axi_iic_0_sda_t),
        .iic2intc_irpt()
    );

	//I/O buff
    IOBUF scl_iobuf (
        .I  (axi_iic_0_scl_o),
        .O  (axi_iic_0_scl_i),
        .T  (axi_iic_0_scl_t),
        .IO (scl)
    );

    IOBUF sda_iobuf (
        .I  (axi_iic_0_sda_o),
        .O  (axi_iic_0_sda_i),
        .T  (axi_iic_0_sda_t),
        .IO (sda)
    );

    assign LED = interface_LED;

endmodule
