`timescale 1ns / 1ps
//------------------------------------------------------------------------------
// Module: max30102_axi_controller
// Description: Controller for MAX30102 pulse oximeter sensor
//              Implements I2C communication via AXI-IIC core
//              Properly handles START/STOP conditions and bus timing
//------------------------------------------------------------------------------
module max30102_axi_controller #(
    parameter C_S_AXI_ADDR_WIDTH = 32,
    parameter C_S_AXI_DATA_WIDTH = 32,
    parameter IIC_BASE_ADDR      = 32'h44A0_0000,
    parameter ADDR_WIDTH         = 12,
    parameter DATA_WIDTH         = 32,
    parameter NUM_SAMPLES        = 1000
)(
    input  wire                           clk,               // System clock
    input  wire                           rst,               // System reset

    input  wire                           start,             // Start acquisition
    output reg                            is_busy,           // Controller busy flag
    output reg                            data_ready,        // Data acquisition complete

    output reg  [ADDR_WIDTH-1:0]          ram_write_addr,    // RAM write address
    output reg  [DATA_WIDTH-1:0]          ram_write_data,    // RAM write data
    output reg                            ram_write_enable,  // RAM write enable

    output wire [15:0]                    debug_leds,        // Debug LEDs

    // AXI-lite master interface signals
    output reg  [C_S_AXI_ADDR_WIDTH-1:0]  axi_awaddr,        // Write address
    output reg                            axi_awvalid,       // Write address valid
    input  wire                           axi_awready,       // Write address ready

    output reg  [C_S_AXI_DATA_WIDTH-1:0]  axi_wdata,         // Write data
    output reg                            axi_wvalid,        // Write data valid
    input  wire                           axi_wready,        // Write data ready

    input  wire  [1:0]                    axi_bresp,         // Write response
    input  wire                           axi_bvalid,        // Write response valid
    output reg                            axi_bready,        // Write response ready

    output reg  [C_S_AXI_ADDR_WIDTH-1:0]  axi_araddr,        // Read address
    output reg                            axi_arvalid,       // Read address valid
    input  wire                           axi_arready,       // Read address ready

    input  wire  [C_S_AXI_DATA_WIDTH-1:0] axi_rdata,         // Read data
    input  wire  [1:0]                    axi_rresp,         // Read response
    input  wire                           axi_rvalid,        // Read data valid
    output reg                            axi_rready         // Read data ready
);

//------------------------------------------------------------------------------
// Local parameters: register offsets and I2C commands
//------------------------------------------------------------------------------
// AXI-IIC Core Register Offsets
localparam REG_CONTROL        = 32'h100;  // Control register
localparam REG_STATUS         = 32'h104;  // Status register
localparam REG_TX_FIFO        = 32'h108;  // Transmit FIFO
localparam REG_RX_FIFO        = 32'h10C;  // Receive FIFO

// Status Register Bit Definitions
localparam SR_TXFIFO_EMPTY    = 7;        // TX FIFO Empty bit
localparam SR_RXFIFO_EMPTY    = 6;        // RX FIFO Empty bit
localparam SR_RXFIFO_FULL     = 5;        // RX FIFO Full bit
localparam SR_BUS_ACTIVE      = 4;        // Bus Active (BA) bit
localparam SR_TX_FIFO_HALF    = 3;        // TX FIFO Half Full bit
localparam SR_DONE            = 2;        // Transfer Done bit
localparam SR_ADDR_SLAVE      = 1;        // Addressed as Slave bit
localparam SR_GEN_CALL        = 0;        // General Call bit

// Control Register Bit Definitions
localparam CR_ENABLE          = 7;        // IIC Enable bit
localparam CR_TX_FIFO_RST     = 2;        // TX FIFO Reset bit
localparam CR_MSMS            = 6;        // Master/Slave Mode Select bit
localparam CR_TX_UNDER        = 5;        // TX Underrun bit
localparam CR_TX_OVER         = 4;        // TX Overrun bit
localparam CR_RX_UNDER        = 3;        // RX Underrun bit
localparam CR_RX_OVER         = 1;        // RX Overrun bit
localparam CR_TXAK            = 0;        // Transmit Acknowledge Enable bit

// I2C Addresses and Commands
localparam I2C_ADDR_WRITE     = 8'hAE;    // MAX30102 I2C address (write)
localparam I2C_ADDR_READ      = 8'hAF;    // MAX30102 I2C address (read)

// MAX30102 Register Addresses
localparam SENSOR_FIFO_WR_PTR = 8'h04;    // FIFO write pointer
localparam SENSOR_FIFO_RD_PTR = 8'h06;    // FIFO read pointer
localparam SENSOR_FIFO_DATA   = 8'h07;    // FIFO data register
localparam SENSOR_MODE_CONFIG = 8'h09;    // Mode configuration
localparam SENSOR_SPO2_CONFIG = 8'h0A;    // SPO2 configuration
localparam SENSOR_LED1_PA     = 8'h0C;    // LED1 pulse amplitude
localparam SENSOR_LED2_PA     = 8'h0D;    // LED2 pulse amplitude

// Configuration Values
localparam MODE_SPO2_HR       = 8'h03;    // SPO2 + Heart Rate mode
localparam SPO2_HI_RES_100SPS = 8'h27;    // 100 SPS, 18-bit resolution
localparam LED_CURRENT_MED    = 8'h24;    // ~7.2mA LED current
localparam FIFO_PTR_RESET     = 8'h00;    // Reset FIFO pointers

// Special I2C Data Flags
localparam I2C_START_BIT      = 9;        // START condition bit position
localparam I2C_STOP_BIT       = 8;        // STOP condition bit position

// State Machine Parameters
localparam BYTES_PER_SAMPLE   = 3;        // Bytes per sample from MAX30102

//------------------------------------------------------------------------------
// State Machine Definition
//------------------------------------------------------------------------------
// Main state machine
localparam STATE_IDLE         = 5'd0;     // Idle state
localparam STATE_RESET_CORE   = 5'd1;     // Reset AXI-IIC core
localparam STATE_CONFIG_START = 5'd2;     // Start configuration sequence
localparam STATE_CONFIG_ADDR  = 5'd3;     // Send register address
localparam STATE_CONFIG_DATA  = 5'd4;     // Send register data
localparam STATE_CONFIG_STOP  = 5'd5;     // Complete configuration
localparam STATE_CONFIG_WAIT  = 5'd6;     // Wait for I2C transaction
localparam STATE_READ_START   = 5'd7;     // Start read transaction
localparam STATE_READ_FIFO    = 5'd8;     // Read FIFO register
localparam STATE_READ_BYTE    = 5'd9;     // Read one byte
localparam STATE_STORE_SAMPLE = 5'd10;    // Store sample in RAM
localparam STATE_DONE         = 5'd11;    // Acquisition complete

// Configuration sequence and parameters
localparam CONFIG_COUNT       = 6;        // Number of registers to configure

// Register arrays for configuration sequence
reg [7:0] config_reg_addr [0:CONFIG_COUNT-1];  // Register addresses
reg [7:0] config_reg_data [0:CONFIG_COUNT-1];  // Register values

// Initialize configuration arrays
initial begin
    // Register addresses
    config_reg_addr[0] = SENSOR_MODE_CONFIG;
    config_reg_addr[1] = SENSOR_SPO2_CONFIG;
    config_reg_addr[2] = SENSOR_LED1_PA;
    config_reg_addr[3] = SENSOR_LED2_PA;
    config_reg_addr[4] = SENSOR_FIFO_WR_PTR;
    config_reg_addr[5] = SENSOR_FIFO_RD_PTR;
    
    // Register values
    config_reg_data[0] = MODE_SPO2_HR;       // SPO2 + HR mode
    config_reg_data[1] = SPO2_HI_RES_100SPS; // 100 SPS, 18-bit
    config_reg_data[2] = LED_CURRENT_MED;    // LED1 current
    config_reg_data[3] = LED_CURRENT_MED;    // LED2 current
    config_reg_data[4] = FIFO_PTR_RESET;     // Reset FIFO write pointer
    config_reg_data[5] = FIFO_PTR_RESET;     // Reset FIFO read pointer
end

//------------------------------------------------------------------------------
// Internal Registers and Signals
//------------------------------------------------------------------------------
// State machine registers
reg [4:0] state;                // Current state
reg [4:0] next_state;           // Next state
reg [2:0] config_index;         // Configuration sequence index
reg [1:0] byte_index;           // Byte index within sample
reg [10:0] sample_count;        // Sample counter
reg [23:0] sample_data;         // Sample data buffer

// Timeout counter
reg [15:0] timeout_counter;     // Timeout counter for safety

// AXI transaction control
reg write_tx_fifo;              // Write to TX FIFO
reg write_control;              // Write to control register
reg read_status;                // Read status register
reg read_rx_fifo;               // Read from RX FIFO
reg [7:0] tx_data_byte;         // Byte to transmit
reg transaction_complete;       // I2C transaction complete flag

// Debug signals
reg state_marker;               // Current state indicator 
reg config_done;                // Configuration complete
reg bus_active;                 // I2C bus active

// Function to calculate logarithm base 2 ceiling
function integer clog2;
    input integer value;
    integer i;
    begin
        clog2 = 0;
        for (i = value-1; i > 0; i = i >> 1)
            clog2 = clog2 + 1;
    end
endfunction

//------------------------------------------------------------------------------
// AXI Transaction Manager
//------------------------------------------------------------------------------
// This block manages low-level AXI transactions by handling handshaking
// timing, and retries if necessary

// Transaction state machine
localparam TRANS_IDLE    = 3'd0;  // No transaction 
localparam TRANS_ADDR    = 3'd1;  // Sending address
localparam TRANS_DATA    = 3'd2;  // Sending/receiving data
localparam TRANS_RESP    = 3'd3;  // Waiting for response
localparam TRANS_DONE    = 3'd4;  // Transaction complete

reg [2:0] trans_state;
reg [2:0] next_trans_state;

// Transaction request signals
reg trans_request;              // Transaction request
reg trans_write;                // 1=Write, 0=Read
reg [31:0] trans_addr;          // Transaction address
reg [31:0] trans_data;          // Transaction data
reg trans_busy;                 // Transaction in progress
reg trans_done;                 // Transaction complete pulse

// Transaction manager state machine
always @(posedge clk) begin
    if (rst) begin
        trans_state <= TRANS_IDLE;
        axi_awvalid <= 1'b0;
        axi_wvalid <= 1'b0;
        axi_arvalid <= 1'b0;
        axi_bready <= 1'b0;
        axi_rready <= 1'b0;
        trans_busy <= 1'b0;
        trans_done <= 1'b0;
    end else begin
        trans_state <= next_trans_state;
        
        // Default pulse signals
        trans_done <= 1'b0;
        
        case (trans_state)
            TRANS_IDLE: begin
                trans_busy <= 1'b0;
                axi_bready <= 1'b0;
                axi_rready <= 1'b0;
                
                if (trans_request) begin
                    trans_busy <= 1'b1;
                    
                    if (trans_write) begin
                        // Setup write address
                        axi_awaddr <= trans_addr;
                        axi_awvalid <= 1'b1;
                        
                        // Setup write data
                        axi_wdata <= trans_data;
                        axi_wvalid <= 1'b1;
                    end else begin
                        // Setup read address
                        axi_araddr <= trans_addr;
                        axi_arvalid <= 1'b1;
                    end
                end
            end
            
            TRANS_ADDR: begin
                // Clear address valid when ready is asserted
                if (trans_write) begin
                    if (axi_awready)
                        axi_awvalid <= 1'b0;
                    
                    // Transition when both address and data are accepted
                    if (!axi_awvalid && !axi_wvalid) begin
                        axi_bready <= 1'b1;
                    end
                end else begin
                    if (axi_arready)
                        axi_arvalid <= 1'b0;
                        
                    if (!axi_arvalid) begin
                        axi_rready <= 1'b1;
                    end
                end
            end
            
            TRANS_DATA: begin
                // For writes, clear data valid when ready is asserted
                if (trans_write) begin
                    if (axi_wready)
                        axi_wvalid <= 1'b0;
                        
                    // Transition when both address and data are accepted
                    if (!axi_awvalid && !axi_wvalid) begin
                        axi_bready <= 1'b1;
                    end
                end
            end
            
            TRANS_RESP: begin
                // Wait for response
                if (trans_write) begin
                    if (axi_bvalid) begin
                        axi_bready <= 1'b0;
                        trans_done <= 1'b1;
                    end
                end else begin
                    if (axi_rvalid) begin
                        axi_rready <= 1'b0;
                        trans_done <= 1'b1;
                    end
                end
            end
            
            TRANS_DONE: begin
                // Transaction complete
            end
        endcase
    end
end

// Transaction manager next state logic
always @(*) begin
    next_trans_state = trans_state;
    
    case (trans_state)
        TRANS_IDLE: begin
            if (trans_request)
                next_trans_state = TRANS_ADDR;
        end
        
        TRANS_ADDR: begin
            if (trans_write) begin
                if (!axi_awvalid && !axi_wvalid)
                    next_trans_state = TRANS_RESP;
            end else begin
                if (!axi_arvalid)
                    next_trans_state = TRANS_RESP;
            end
        end
        
        TRANS_DATA: begin
            if (trans_write) begin
                if (!axi_awvalid && !axi_wvalid)
                    next_trans_state = TRANS_RESP;
            end
        end
        
        TRANS_RESP: begin
            if (trans_write) begin
                if (axi_bvalid)
                    next_trans_state = TRANS_DONE;
            end else begin
                if (axi_rvalid)
                    next_trans_state = TRANS_DONE;
            end
        end
        
        TRANS_DONE: begin
            next_trans_state = TRANS_IDLE;
        end
    endcase
end

//------------------------------------------------------------------------------
// I2C Transaction Manager
//------------------------------------------------------------------------------
// This block manages I2C operations and translates them into AXI transactions

// Start a new AXI transaction
task start_transaction;
    input write_transaction;
    input [31:0] address;
    input [31:0] data;
begin
    trans_request <= 1'b1;
    trans_write <= write_transaction;
    trans_addr <= address;
    trans_data <= data;
end
endtask

// Wait for transaction to complete
task wait_transaction;
begin
    trans_request <= 1'b0;
    timeout_counter <= 16'h0;
end
endtask

// I2C transaction manager - handles AXI to I2C translation
always @(posedge clk) begin
    if (rst) begin
        write_tx_fifo <= 1'b0;
        write_control <= 1'b0;
        read_status <= 1'b0;
        read_rx_fifo <= 1'b0;
        tx_data_byte <= 8'h00;
        transaction_complete <= 1'b0;
        trans_request <= 1'b0;
        timeout_counter <= 16'h0;
    end else begin
        // Default signal states
        transaction_complete <= 1'b0;
        
        // Handle transaction requests
        if (write_tx_fifo) begin
            write_tx_fifo <= 1'b0;
            start_transaction(1'b1, IIC_BASE_ADDR + REG_TX_FIFO, {24'h0, tx_data_byte});
        end
        
        if (write_control) begin
            write_control <= 1'b0;
            // Enable IIC core, set MSMS bit (start), don't reset TX FIFO
            start_transaction(1'b1, IIC_BASE_ADDR + REG_CONTROL, 32'h0000_00C2);
        end
        
        if (read_status) begin
            read_status <= 1'b0;
            start_transaction(1'b0, IIC_BASE_ADDR + REG_STATUS, 32'h0);
        end
        
        if (read_rx_fifo) begin
            read_rx_fifo <= 1'b0;
            start_transaction(1'b0, IIC_BASE_ADDR + REG_RX_FIFO, 32'h0);
        end
        
        // Handle transaction completion
        if (trans_done) begin
            transaction_complete <= 1'b1;
            timeout_counter <= 16'h0;
        end
        
        // Timeout counter to prevent hangs
        if (trans_busy) begin
            timeout_counter <= timeout_counter + 1'b1;
            if (timeout_counter == 16'hFFFF) begin
                // Transaction timed out - force completion
                trans_request <= 1'b0;
                transaction_complete <= 1'b1;
            end
        end
    end
end

//------------------------------------------------------------------------------
// Main State Machine
//------------------------------------------------------------------------------
// Main controller state machine - handles the MAX30102 configuration and
// data acquisition sequence

// Next state logic
always @(*) begin
    next_state = state;
    write_tx_fifo = 1'b0;
    write_control = 1'b0;
    read_status = 1'b0;
    read_rx_fifo = 1'b0;
    tx_data_byte = 8'h00;
    
    case (state)
        STATE_IDLE: begin
            if (start)
                next_state = STATE_RESET_CORE;
        end
        
        STATE_RESET_CORE: begin
            // Reset AXI-IIC core before starting
            write_control = 1'b1;
            tx_data_byte = 8'h00; // Reset control register
            next_state = STATE_CONFIG_START;
        end
        
        STATE_CONFIG_START: begin
            // Start I2C transaction with slave address
            if (!trans_busy && transaction_complete) begin
                write_tx_fifo = 1'b1;
                tx_data_byte = I2C_ADDR_WRITE; // Write to MAX30102
                next_state = STATE_CONFIG_ADDR;
            end
        end
        
        STATE_CONFIG_ADDR: begin
            // Send register address
            if (!trans_busy && transaction_complete) begin
                write_tx_fifo = 1'b1;
                tx_data_byte = config_reg_addr[config_index];
                next_state = STATE_CONFIG_DATA;
            end
        end
        
        STATE_CONFIG_DATA: begin
            // Send register data
            if (!trans_busy && transaction_complete) begin
                write_tx_fifo = 1'b1;
                tx_data_byte = config_reg_data[config_index];
                next_state = STATE_CONFIG_STOP;
            end
        end
        
        STATE_CONFIG_STOP: begin
            // Initiate the I2C transaction
            if (!trans_busy && transaction_complete) begin
                write_control = 1'b1;
                next_state = STATE_CONFIG_WAIT;
            end
        end
        
        STATE_CONFIG_WAIT: begin
            // Wait for I2C transaction to complete (bus to be idle)
            if (!trans_busy) begin
                read_status = 1'b1;
                next_state = STATE_CONFIG_WAIT;
            end else if (transaction_complete) begin
                // Check if bus is inactive (BA=0)
                if ((axi_rdata[SR_BUS_ACTIVE] == 1'b0) && (axi_rdata[SR_DONE] == 1'b1)) begin
                    if (config_index == CONFIG_COUNT-1) begin
                        // Configuration complete, start reading data
                        next_state = STATE_READ_START;
                    end else begin
                        // More registers to configure
                        next_state = STATE_CONFIG_START;
                    end
                end else begin
                    // Keep waiting for transaction to complete
                    next_state = STATE_CONFIG_WAIT;
                end
            end
        end
        
        STATE_READ_START: begin
            // Start read transaction with read address
            if (!trans_busy) begin
                write_tx_fifo = 1'b1;
                tx_data_byte = I2C_ADDR_READ; // Add START bit
                next_state = STATE_READ_FIFO;
            end
        end
        
        STATE_READ_FIFO: begin
            // Send FIFO data register address
            if (!trans_busy && transaction_complete) begin
                write_tx_fifo = 1'b1;
                tx_data_byte = SENSOR_FIFO_DATA;
                write_control = 1'b1; // Start I2C transaction
                next_state = STATE_READ_BYTE;
            end
        end
        
        STATE_READ_BYTE: begin
            // Read a byte from the RX FIFO
            if (!trans_busy) begin
                read_rx_fifo = 1'b1;
                next_state = STATE_READ_BYTE;
            end else if (transaction_complete) begin
                if (byte_index == BYTES_PER_SAMPLE-1) begin
                    // Complete sample received
                    next_state = STATE_STORE_SAMPLE;
                end else begin
                    // Need more bytes for this sample
                    next_state = STATE_READ_BYTE;
                end
            end
        end
        
        STATE_STORE_SAMPLE: begin
            // Store sample in RAM and check if we're done
            if (sample_count == NUM_SAMPLES-1) begin
                next_state = STATE_DONE;
            end else begin
                // Get next sample
                next_state = STATE_READ_BYTE;
            end
        end
        
        STATE_DONE: begin
            // Acquisition complete
            if (!start)
                next_state = STATE_IDLE;
        end
        
        default: begin
            next_state = STATE_IDLE;
        end
    endcase
end

// State machine sequential logic
always @(posedge clk) begin
    if (rst) begin
        state <= STATE_IDLE;
        config_index <= 3'd0;
        byte_index <= 2'd0;
        sample_count <= 11'd0;
        sample_data <= 24'd0;
        is_busy <= 1'b0;
        data_ready <= 1'b0;
        ram_write_enable <= 1'b0;
        ram_write_addr <= {ADDR_WIDTH{1'b0}};
        ram_write_data <= {DATA_WIDTH{1'b0}};
        state_marker <= 1'b0;
        config_done <= 1'b0;
        bus_active <= 1'b0;
    end else begin
        state <= next_state;
        
        // Default signal states
        ram_write_enable <= 1'b0;
        data_ready <= 1'b0;
        
        // Set busy flag when not in IDLE or DONE
        is_busy <= (state != STATE_IDLE && state != STATE_DONE);
        
        // State transitions
        case (state)
            STATE_IDLE: begin
                config_index <= 3'd0;
                byte_index <= 2'd0;
                sample_count <= 11'd0;
                state_marker <= 1'b0;
                config_done <= 1'b0;
            end
            
            STATE_CONFIG_WAIT: begin
                if (next_state == STATE_CONFIG_START && state == STATE_CONFIG_WAIT) begin
                    // Increment configuration index when moving to next register
                    config_index <= config_index + 1'b1;
                end
                
                // Update bus active status from status register
                if (transaction_complete) begin
                    bus_active <= axi_rdata[SR_BUS_ACTIVE];
                end
            end
            
            STATE_READ_START: begin
                // Set flag indicating configuration is done
                config_done <= 1'b1;
                byte_index <= 2'd0;
            end
            
            STATE_READ_BYTE: begin
                if (transaction_complete) begin
                    // Store received byte in sample data buffer
                    case (byte_index)
                        2'd0: sample_data[23:16] <= axi_rdata[7:0];
                        2'd1: sample_data[15:8] <= axi_rdata[7:0];
                        2'd2: sample_data[7:0] <= axi_rdata[7:0];
                    endcase
                    
                    // Increment byte index
                    byte_index <= byte_index + 1'b1;
                end
            end
            
            STATE_STORE_SAMPLE: begin
                // Write sample to RAM
                ram_write_enable <= 1'b1;
                ram_write_addr <= sample_count;
                ram_write_data <= {8'd0, sample_data}; // Pad with zeros
                
                // Increment sample counter
                sample_count <= sample_count + 1'b1;
                
                // Reset byte index for next sample
                byte_index <= 2'd0;
            end
            
            STATE_DONE: begin
                data_ready <= 1'b1;
                state_marker <= 1'b1;
            end
        endcase
    end
end

//------------------------------------------------------------------------------
// Debug LED outputs
//------------------------------------------------------------------------------
// Map debug signals to LEDs
assign debug_leds[15] = state_marker;           // STATE_DONE indicator
assign debug_leds[14] = config_done;            // Configuration complete
assign debug_leds[13] = bus_active;             // I2C bus active
assign debug_leds[12] = transaction_complete;   // Transaction complete pulse
assign debug_leds[11:9] = trans_state;          // Transaction state
assign debug_leds[8] = trans_busy;              // Transaction in progress
assign debug_leds[7:5] = config_index;          // Configuration index
assign debug_leds[4:0] = state;                 // Current state

endmodule