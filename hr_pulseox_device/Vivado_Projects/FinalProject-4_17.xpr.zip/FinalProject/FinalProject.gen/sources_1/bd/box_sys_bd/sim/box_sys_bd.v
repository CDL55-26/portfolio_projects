//Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
//Date        : Thu Apr 17 00:25:17 2025
//Host        : P1-05 running 64-bit major release  (build 9200)
//Command     : generate_target box_sys_bd.bd
//Design      : box_sys_bd
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "box_sys_bd,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=box_sys_bd,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=6,numReposBlks=4,numNonXlnxBlks=0,numHierBlks=2,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=1,numPkgbdBlks=0,bdsource=USER,da_axi4_cnt=1,da_board_cnt=4,synth_mode=OOC_per_IP}" *) (* HW_HANDOFF = "box_sys_bd.hwdef" *) 
module box_sys_bd
   (clk_100MHz,
    reset_rtl_0,
    scl_0,
    sda_0);
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_100MHZ CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_100MHZ, CLK_DOMAIN box_sys_bd_clk_100MHz, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk_100MHz;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RESET_RTL_0 RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RESET_RTL_0, INSERT_VIP 0, POLARITY ACTIVE_HIGH" *) input reset_rtl_0;
  inout scl_0;
  inout sda_0;

  wire Net;
  wire Net1;
  wire Net2;
  wire Net3;
  wire [31:0]Wrapper_0_axi_periph_M00_AXI_ARADDR;
  wire Wrapper_0_axi_periph_M00_AXI_ARREADY;
  wire Wrapper_0_axi_periph_M00_AXI_ARVALID;
  wire [31:0]Wrapper_0_axi_periph_M00_AXI_AWADDR;
  wire Wrapper_0_axi_periph_M00_AXI_AWREADY;
  wire Wrapper_0_axi_periph_M00_AXI_AWVALID;
  wire Wrapper_0_axi_periph_M00_AXI_BREADY;
  wire [1:0]Wrapper_0_axi_periph_M00_AXI_BRESP;
  wire Wrapper_0_axi_periph_M00_AXI_BVALID;
  wire [31:0]Wrapper_0_axi_periph_M00_AXI_RDATA;
  wire Wrapper_0_axi_periph_M00_AXI_RREADY;
  wire [1:0]Wrapper_0_axi_periph_M00_AXI_RRESP;
  wire Wrapper_0_axi_periph_M00_AXI_RVALID;
  wire [31:0]Wrapper_0_axi_periph_M00_AXI_WDATA;
  wire Wrapper_0_axi_periph_M00_AXI_WREADY;
  wire Wrapper_0_axi_periph_M00_AXI_WVALID;
  wire [31:0]Wrapper_0_s_axi_ARADDR;
  wire Wrapper_0_s_axi_ARREADY;
  wire Wrapper_0_s_axi_ARVALID;
  wire [31:0]Wrapper_0_s_axi_AWADDR;
  wire Wrapper_0_s_axi_AWREADY;
  wire Wrapper_0_s_axi_AWVALID;
  wire Wrapper_0_s_axi_BREADY;
  wire [1:0]Wrapper_0_s_axi_BRESP;
  wire Wrapper_0_s_axi_BVALID;
  wire [31:0]Wrapper_0_s_axi_RDATA;
  wire Wrapper_0_s_axi_RREADY;
  wire [1:0]Wrapper_0_s_axi_RRESP;
  wire Wrapper_0_s_axi_RVALID;
  wire [31:0]Wrapper_0_s_axi_WDATA;
  wire Wrapper_0_s_axi_WREADY;
  wire Wrapper_0_s_axi_WVALID;
  wire axi_iic_0_scl_o;
  wire axi_iic_0_scl_t;
  wire axi_iic_0_sda_o;
  wire axi_iic_0_sda_t;
  wire clk_100MHz_1;
  wire clk_wiz_clk_out1;
  wire clk_wiz_locked;
  wire reset_rtl_0_1;
  wire [0:0]rst_clk_wiz_100M_peripheral_aresetn;

  assign clk_100MHz_1 = clk_100MHz;
  assign reset_rtl_0_1 = reset_rtl_0;
  box_sys_bd_Wrapper_0_0 Wrapper_0
       (.axi_iic_0_scl_i(Net),
        .axi_iic_0_scl_o(axi_iic_0_scl_o),
        .axi_iic_0_scl_t(axi_iic_0_scl_t),
        .axi_iic_0_sda_i(Net1),
        .axi_iic_0_sda_o(axi_iic_0_sda_o),
        .axi_iic_0_sda_t(axi_iic_0_sda_t),
        .clock(clk_wiz_clk_out1),
        .reset_rtl_0(reset_rtl_0_1),
        .s_axi_araddr(Wrapper_0_s_axi_ARADDR),
        .s_axi_arready(Wrapper_0_s_axi_ARREADY),
        .s_axi_arvalid(Wrapper_0_s_axi_ARVALID),
        .s_axi_awaddr(Wrapper_0_s_axi_AWADDR),
        .s_axi_awready(Wrapper_0_s_axi_AWREADY),
        .s_axi_awvalid(Wrapper_0_s_axi_AWVALID),
        .s_axi_bready(Wrapper_0_s_axi_BREADY),
        .s_axi_bresp(Wrapper_0_s_axi_BRESP),
        .s_axi_bvalid(Wrapper_0_s_axi_BVALID),
        .s_axi_rdata(Wrapper_0_s_axi_RDATA),
        .s_axi_rready(Wrapper_0_s_axi_RREADY),
        .s_axi_rresp(Wrapper_0_s_axi_RRESP),
        .s_axi_rvalid(Wrapper_0_s_axi_RVALID),
        .s_axi_wdata(Wrapper_0_s_axi_WDATA),
        .s_axi_wready(Wrapper_0_s_axi_WREADY),
        .s_axi_wvalid(Wrapper_0_s_axi_WVALID),
        .scl(scl_0),
        .sda(sda_0));
  box_sys_bd_Wrapper_0_axi_periph_0 Wrapper_0_axi_periph
       (.ACLK(clk_wiz_clk_out1),
        .ARESETN(rst_clk_wiz_100M_peripheral_aresetn),
        .M00_ACLK(clk_wiz_clk_out1),
        .M00_ARESETN(rst_clk_wiz_100M_peripheral_aresetn),
        .M00_AXI_araddr(Wrapper_0_axi_periph_M00_AXI_ARADDR),
        .M00_AXI_arready(Wrapper_0_axi_periph_M00_AXI_ARREADY),
        .M00_AXI_arvalid(Wrapper_0_axi_periph_M00_AXI_ARVALID),
        .M00_AXI_awaddr(Wrapper_0_axi_periph_M00_AXI_AWADDR),
        .M00_AXI_awready(Wrapper_0_axi_periph_M00_AXI_AWREADY),
        .M00_AXI_awvalid(Wrapper_0_axi_periph_M00_AXI_AWVALID),
        .M00_AXI_bready(Wrapper_0_axi_periph_M00_AXI_BREADY),
        .M00_AXI_bresp(Wrapper_0_axi_periph_M00_AXI_BRESP),
        .M00_AXI_bvalid(Wrapper_0_axi_periph_M00_AXI_BVALID),
        .M00_AXI_rdata(Wrapper_0_axi_periph_M00_AXI_RDATA),
        .M00_AXI_rready(Wrapper_0_axi_periph_M00_AXI_RREADY),
        .M00_AXI_rresp(Wrapper_0_axi_periph_M00_AXI_RRESP),
        .M00_AXI_rvalid(Wrapper_0_axi_periph_M00_AXI_RVALID),
        .M00_AXI_wdata(Wrapper_0_axi_periph_M00_AXI_WDATA),
        .M00_AXI_wready(Wrapper_0_axi_periph_M00_AXI_WREADY),
        .M00_AXI_wvalid(Wrapper_0_axi_periph_M00_AXI_WVALID),
        .S00_ACLK(clk_wiz_clk_out1),
        .S00_ARESETN(rst_clk_wiz_100M_peripheral_aresetn),
        .S00_AXI_araddr(Wrapper_0_s_axi_ARADDR),
        .S00_AXI_arready(Wrapper_0_s_axi_ARREADY),
        .S00_AXI_arvalid(Wrapper_0_s_axi_ARVALID),
        .S00_AXI_awaddr(Wrapper_0_s_axi_AWADDR),
        .S00_AXI_awready(Wrapper_0_s_axi_AWREADY),
        .S00_AXI_awvalid(Wrapper_0_s_axi_AWVALID),
        .S00_AXI_bready(Wrapper_0_s_axi_BREADY),
        .S00_AXI_bresp(Wrapper_0_s_axi_BRESP),
        .S00_AXI_bvalid(Wrapper_0_s_axi_BVALID),
        .S00_AXI_rdata(Wrapper_0_s_axi_RDATA),
        .S00_AXI_rready(Wrapper_0_s_axi_RREADY),
        .S00_AXI_rresp(Wrapper_0_s_axi_RRESP),
        .S00_AXI_rvalid(Wrapper_0_s_axi_RVALID),
        .S00_AXI_wdata(Wrapper_0_s_axi_WDATA),
        .S00_AXI_wready(Wrapper_0_s_axi_WREADY),
        .S00_AXI_wvalid(Wrapper_0_s_axi_WVALID));
  box_sys_bd_axi_iic_0_0 axi_iic_0
       (.s_axi_aclk(clk_wiz_clk_out1),
        .s_axi_araddr(Wrapper_0_axi_periph_M00_AXI_ARADDR[8:0]),
        .s_axi_aresetn(rst_clk_wiz_100M_peripheral_aresetn),
        .s_axi_arready(Wrapper_0_axi_periph_M00_AXI_ARREADY),
        .s_axi_arvalid(Wrapper_0_axi_periph_M00_AXI_ARVALID),
        .s_axi_awaddr(Wrapper_0_axi_periph_M00_AXI_AWADDR[8:0]),
        .s_axi_awready(Wrapper_0_axi_periph_M00_AXI_AWREADY),
        .s_axi_awvalid(Wrapper_0_axi_periph_M00_AXI_AWVALID),
        .s_axi_bready(Wrapper_0_axi_periph_M00_AXI_BREADY),
        .s_axi_bresp(Wrapper_0_axi_periph_M00_AXI_BRESP),
        .s_axi_bvalid(Wrapper_0_axi_periph_M00_AXI_BVALID),
        .s_axi_rdata(Wrapper_0_axi_periph_M00_AXI_RDATA),
        .s_axi_rready(Wrapper_0_axi_periph_M00_AXI_RREADY),
        .s_axi_rresp(Wrapper_0_axi_periph_M00_AXI_RRESP),
        .s_axi_rvalid(Wrapper_0_axi_periph_M00_AXI_RVALID),
        .s_axi_wdata(Wrapper_0_axi_periph_M00_AXI_WDATA),
        .s_axi_wready(Wrapper_0_axi_periph_M00_AXI_WREADY),
        .s_axi_wstrb({1'b1,1'b1,1'b1,1'b1}),
        .s_axi_wvalid(Wrapper_0_axi_periph_M00_AXI_WVALID),
        .scl_i(Net),
        .scl_o(axi_iic_0_scl_o),
        .scl_t(axi_iic_0_scl_t),
        .sda_i(Net1),
        .sda_o(axi_iic_0_sda_o),
        .sda_t(axi_iic_0_sda_t));
  box_sys_bd_clk_wiz_0 clk_wiz
       (.clk_in1(clk_100MHz_1),
        .clk_out1(clk_wiz_clk_out1),
        .locked(clk_wiz_locked),
        .reset(reset_rtl_0_1));
  box_sys_bd_rst_clk_wiz_100M_0 rst_clk_wiz_100M
       (.aux_reset_in(1'b1),
        .dcm_locked(clk_wiz_locked),
        .ext_reset_in(reset_rtl_0_1),
        .mb_debug_sys_rst(1'b0),
        .peripheral_aresetn(rst_clk_wiz_100M_peripheral_aresetn),
        .slowest_sync_clk(clk_wiz_clk_out1));
endmodule

module box_sys_bd_Wrapper_0_axi_periph_0
   (ACLK,
    ARESETN,
    M00_ACLK,
    M00_ARESETN,
    M00_AXI_araddr,
    M00_AXI_arready,
    M00_AXI_arvalid,
    M00_AXI_awaddr,
    M00_AXI_awready,
    M00_AXI_awvalid,
    M00_AXI_bready,
    M00_AXI_bresp,
    M00_AXI_bvalid,
    M00_AXI_rdata,
    M00_AXI_rready,
    M00_AXI_rresp,
    M00_AXI_rvalid,
    M00_AXI_wdata,
    M00_AXI_wready,
    M00_AXI_wvalid,
    S00_ACLK,
    S00_ARESETN,
    S00_AXI_araddr,
    S00_AXI_arready,
    S00_AXI_arvalid,
    S00_AXI_awaddr,
    S00_AXI_awready,
    S00_AXI_awvalid,
    S00_AXI_bready,
    S00_AXI_bresp,
    S00_AXI_bvalid,
    S00_AXI_rdata,
    S00_AXI_rready,
    S00_AXI_rresp,
    S00_AXI_rvalid,
    S00_AXI_wdata,
    S00_AXI_wready,
    S00_AXI_wvalid);
  input ACLK;
  input ARESETN;
  input M00_ACLK;
  input M00_ARESETN;
  output [31:0]M00_AXI_araddr;
  input M00_AXI_arready;
  output M00_AXI_arvalid;
  output [31:0]M00_AXI_awaddr;
  input M00_AXI_awready;
  output M00_AXI_awvalid;
  output M00_AXI_bready;
  input [1:0]M00_AXI_bresp;
  input M00_AXI_bvalid;
  input [31:0]M00_AXI_rdata;
  output M00_AXI_rready;
  input [1:0]M00_AXI_rresp;
  input M00_AXI_rvalid;
  output [31:0]M00_AXI_wdata;
  input M00_AXI_wready;
  output M00_AXI_wvalid;
  input S00_ACLK;
  input S00_ARESETN;
  input [31:0]S00_AXI_araddr;
  output S00_AXI_arready;
  input S00_AXI_arvalid;
  input [31:0]S00_AXI_awaddr;
  output S00_AXI_awready;
  input S00_AXI_awvalid;
  input S00_AXI_bready;
  output [1:0]S00_AXI_bresp;
  output S00_AXI_bvalid;
  output [31:0]S00_AXI_rdata;
  input S00_AXI_rready;
  output [1:0]S00_AXI_rresp;
  output S00_AXI_rvalid;
  input [31:0]S00_AXI_wdata;
  output S00_AXI_wready;
  input S00_AXI_wvalid;

  wire S00_ACLK_1;
  wire S00_ARESETN_1;
  wire Wrapper_0_axi_periph_ACLK_net;
  wire Wrapper_0_axi_periph_ARESETN_net;
  wire [31:0]Wrapper_0_axi_periph_to_s00_couplers_ARADDR;
  wire Wrapper_0_axi_periph_to_s00_couplers_ARREADY;
  wire Wrapper_0_axi_periph_to_s00_couplers_ARVALID;
  wire [31:0]Wrapper_0_axi_periph_to_s00_couplers_AWADDR;
  wire Wrapper_0_axi_periph_to_s00_couplers_AWREADY;
  wire Wrapper_0_axi_periph_to_s00_couplers_AWVALID;
  wire Wrapper_0_axi_periph_to_s00_couplers_BREADY;
  wire [1:0]Wrapper_0_axi_periph_to_s00_couplers_BRESP;
  wire Wrapper_0_axi_periph_to_s00_couplers_BVALID;
  wire [31:0]Wrapper_0_axi_periph_to_s00_couplers_RDATA;
  wire Wrapper_0_axi_periph_to_s00_couplers_RREADY;
  wire [1:0]Wrapper_0_axi_periph_to_s00_couplers_RRESP;
  wire Wrapper_0_axi_periph_to_s00_couplers_RVALID;
  wire [31:0]Wrapper_0_axi_periph_to_s00_couplers_WDATA;
  wire Wrapper_0_axi_periph_to_s00_couplers_WREADY;
  wire Wrapper_0_axi_periph_to_s00_couplers_WVALID;
  wire [31:0]s00_couplers_to_Wrapper_0_axi_periph_ARADDR;
  wire s00_couplers_to_Wrapper_0_axi_periph_ARREADY;
  wire s00_couplers_to_Wrapper_0_axi_periph_ARVALID;
  wire [31:0]s00_couplers_to_Wrapper_0_axi_periph_AWADDR;
  wire s00_couplers_to_Wrapper_0_axi_periph_AWREADY;
  wire s00_couplers_to_Wrapper_0_axi_periph_AWVALID;
  wire s00_couplers_to_Wrapper_0_axi_periph_BREADY;
  wire [1:0]s00_couplers_to_Wrapper_0_axi_periph_BRESP;
  wire s00_couplers_to_Wrapper_0_axi_periph_BVALID;
  wire [31:0]s00_couplers_to_Wrapper_0_axi_periph_RDATA;
  wire s00_couplers_to_Wrapper_0_axi_periph_RREADY;
  wire [1:0]s00_couplers_to_Wrapper_0_axi_periph_RRESP;
  wire s00_couplers_to_Wrapper_0_axi_periph_RVALID;
  wire [31:0]s00_couplers_to_Wrapper_0_axi_periph_WDATA;
  wire s00_couplers_to_Wrapper_0_axi_periph_WREADY;
  wire s00_couplers_to_Wrapper_0_axi_periph_WVALID;

  assign M00_AXI_araddr[31:0] = s00_couplers_to_Wrapper_0_axi_periph_ARADDR;
  assign M00_AXI_arvalid = s00_couplers_to_Wrapper_0_axi_periph_ARVALID;
  assign M00_AXI_awaddr[31:0] = s00_couplers_to_Wrapper_0_axi_periph_AWADDR;
  assign M00_AXI_awvalid = s00_couplers_to_Wrapper_0_axi_periph_AWVALID;
  assign M00_AXI_bready = s00_couplers_to_Wrapper_0_axi_periph_BREADY;
  assign M00_AXI_rready = s00_couplers_to_Wrapper_0_axi_periph_RREADY;
  assign M00_AXI_wdata[31:0] = s00_couplers_to_Wrapper_0_axi_periph_WDATA;
  assign M00_AXI_wvalid = s00_couplers_to_Wrapper_0_axi_periph_WVALID;
  assign S00_ACLK_1 = S00_ACLK;
  assign S00_ARESETN_1 = S00_ARESETN;
  assign S00_AXI_arready = Wrapper_0_axi_periph_to_s00_couplers_ARREADY;
  assign S00_AXI_awready = Wrapper_0_axi_periph_to_s00_couplers_AWREADY;
  assign S00_AXI_bresp[1:0] = Wrapper_0_axi_periph_to_s00_couplers_BRESP;
  assign S00_AXI_bvalid = Wrapper_0_axi_periph_to_s00_couplers_BVALID;
  assign S00_AXI_rdata[31:0] = Wrapper_0_axi_periph_to_s00_couplers_RDATA;
  assign S00_AXI_rresp[1:0] = Wrapper_0_axi_periph_to_s00_couplers_RRESP;
  assign S00_AXI_rvalid = Wrapper_0_axi_periph_to_s00_couplers_RVALID;
  assign S00_AXI_wready = Wrapper_0_axi_periph_to_s00_couplers_WREADY;
  assign Wrapper_0_axi_periph_ACLK_net = M00_ACLK;
  assign Wrapper_0_axi_periph_ARESETN_net = M00_ARESETN;
  assign Wrapper_0_axi_periph_to_s00_couplers_ARADDR = S00_AXI_araddr[31:0];
  assign Wrapper_0_axi_periph_to_s00_couplers_ARVALID = S00_AXI_arvalid;
  assign Wrapper_0_axi_periph_to_s00_couplers_AWADDR = S00_AXI_awaddr[31:0];
  assign Wrapper_0_axi_periph_to_s00_couplers_AWVALID = S00_AXI_awvalid;
  assign Wrapper_0_axi_periph_to_s00_couplers_BREADY = S00_AXI_bready;
  assign Wrapper_0_axi_periph_to_s00_couplers_RREADY = S00_AXI_rready;
  assign Wrapper_0_axi_periph_to_s00_couplers_WDATA = S00_AXI_wdata[31:0];
  assign Wrapper_0_axi_periph_to_s00_couplers_WVALID = S00_AXI_wvalid;
  assign s00_couplers_to_Wrapper_0_axi_periph_ARREADY = M00_AXI_arready;
  assign s00_couplers_to_Wrapper_0_axi_periph_AWREADY = M00_AXI_awready;
  assign s00_couplers_to_Wrapper_0_axi_periph_BRESP = M00_AXI_bresp[1:0];
  assign s00_couplers_to_Wrapper_0_axi_periph_BVALID = M00_AXI_bvalid;
  assign s00_couplers_to_Wrapper_0_axi_periph_RDATA = M00_AXI_rdata[31:0];
  assign s00_couplers_to_Wrapper_0_axi_periph_RRESP = M00_AXI_rresp[1:0];
  assign s00_couplers_to_Wrapper_0_axi_periph_RVALID = M00_AXI_rvalid;
  assign s00_couplers_to_Wrapper_0_axi_periph_WREADY = M00_AXI_wready;
  s00_couplers_imp_O8LI75 s00_couplers
       (.M_ACLK(Wrapper_0_axi_periph_ACLK_net),
        .M_ARESETN(Wrapper_0_axi_periph_ARESETN_net),
        .M_AXI_araddr(s00_couplers_to_Wrapper_0_axi_periph_ARADDR),
        .M_AXI_arready(s00_couplers_to_Wrapper_0_axi_periph_ARREADY),
        .M_AXI_arvalid(s00_couplers_to_Wrapper_0_axi_periph_ARVALID),
        .M_AXI_awaddr(s00_couplers_to_Wrapper_0_axi_periph_AWADDR),
        .M_AXI_awready(s00_couplers_to_Wrapper_0_axi_periph_AWREADY),
        .M_AXI_awvalid(s00_couplers_to_Wrapper_0_axi_periph_AWVALID),
        .M_AXI_bready(s00_couplers_to_Wrapper_0_axi_periph_BREADY),
        .M_AXI_bresp(s00_couplers_to_Wrapper_0_axi_periph_BRESP),
        .M_AXI_bvalid(s00_couplers_to_Wrapper_0_axi_periph_BVALID),
        .M_AXI_rdata(s00_couplers_to_Wrapper_0_axi_periph_RDATA),
        .M_AXI_rready(s00_couplers_to_Wrapper_0_axi_periph_RREADY),
        .M_AXI_rresp(s00_couplers_to_Wrapper_0_axi_periph_RRESP),
        .M_AXI_rvalid(s00_couplers_to_Wrapper_0_axi_periph_RVALID),
        .M_AXI_wdata(s00_couplers_to_Wrapper_0_axi_periph_WDATA),
        .M_AXI_wready(s00_couplers_to_Wrapper_0_axi_periph_WREADY),
        .M_AXI_wvalid(s00_couplers_to_Wrapper_0_axi_periph_WVALID),
        .S_ACLK(S00_ACLK_1),
        .S_ARESETN(S00_ARESETN_1),
        .S_AXI_araddr(Wrapper_0_axi_periph_to_s00_couplers_ARADDR),
        .S_AXI_arready(Wrapper_0_axi_periph_to_s00_couplers_ARREADY),
        .S_AXI_arvalid(Wrapper_0_axi_periph_to_s00_couplers_ARVALID),
        .S_AXI_awaddr(Wrapper_0_axi_periph_to_s00_couplers_AWADDR),
        .S_AXI_awready(Wrapper_0_axi_periph_to_s00_couplers_AWREADY),
        .S_AXI_awvalid(Wrapper_0_axi_periph_to_s00_couplers_AWVALID),
        .S_AXI_bready(Wrapper_0_axi_periph_to_s00_couplers_BREADY),
        .S_AXI_bresp(Wrapper_0_axi_periph_to_s00_couplers_BRESP),
        .S_AXI_bvalid(Wrapper_0_axi_periph_to_s00_couplers_BVALID),
        .S_AXI_rdata(Wrapper_0_axi_periph_to_s00_couplers_RDATA),
        .S_AXI_rready(Wrapper_0_axi_periph_to_s00_couplers_RREADY),
        .S_AXI_rresp(Wrapper_0_axi_periph_to_s00_couplers_RRESP),
        .S_AXI_rvalid(Wrapper_0_axi_periph_to_s00_couplers_RVALID),
        .S_AXI_wdata(Wrapper_0_axi_periph_to_s00_couplers_WDATA),
        .S_AXI_wready(Wrapper_0_axi_periph_to_s00_couplers_WREADY),
        .S_AXI_wvalid(Wrapper_0_axi_periph_to_s00_couplers_WVALID));
endmodule

module s00_couplers_imp_O8LI75
   (M_ACLK,
    M_ARESETN,
    M_AXI_araddr,
    M_AXI_arready,
    M_AXI_arvalid,
    M_AXI_awaddr,
    M_AXI_awready,
    M_AXI_awvalid,
    M_AXI_bready,
    M_AXI_bresp,
    M_AXI_bvalid,
    M_AXI_rdata,
    M_AXI_rready,
    M_AXI_rresp,
    M_AXI_rvalid,
    M_AXI_wdata,
    M_AXI_wready,
    M_AXI_wvalid,
    S_ACLK,
    S_ARESETN,
    S_AXI_araddr,
    S_AXI_arready,
    S_AXI_arvalid,
    S_AXI_awaddr,
    S_AXI_awready,
    S_AXI_awvalid,
    S_AXI_bready,
    S_AXI_bresp,
    S_AXI_bvalid,
    S_AXI_rdata,
    S_AXI_rready,
    S_AXI_rresp,
    S_AXI_rvalid,
    S_AXI_wdata,
    S_AXI_wready,
    S_AXI_wvalid);
  input M_ACLK;
  input M_ARESETN;
  output [31:0]M_AXI_araddr;
  input M_AXI_arready;
  output M_AXI_arvalid;
  output [31:0]M_AXI_awaddr;
  input M_AXI_awready;
  output M_AXI_awvalid;
  output M_AXI_bready;
  input [1:0]M_AXI_bresp;
  input M_AXI_bvalid;
  input [31:0]M_AXI_rdata;
  output M_AXI_rready;
  input [1:0]M_AXI_rresp;
  input M_AXI_rvalid;
  output [31:0]M_AXI_wdata;
  input M_AXI_wready;
  output M_AXI_wvalid;
  input S_ACLK;
  input S_ARESETN;
  input [31:0]S_AXI_araddr;
  output S_AXI_arready;
  input S_AXI_arvalid;
  input [31:0]S_AXI_awaddr;
  output S_AXI_awready;
  input S_AXI_awvalid;
  input S_AXI_bready;
  output [1:0]S_AXI_bresp;
  output S_AXI_bvalid;
  output [31:0]S_AXI_rdata;
  input S_AXI_rready;
  output [1:0]S_AXI_rresp;
  output S_AXI_rvalid;
  input [31:0]S_AXI_wdata;
  output S_AXI_wready;
  input S_AXI_wvalid;

  wire [31:0]s00_couplers_to_s00_couplers_ARADDR;
  wire s00_couplers_to_s00_couplers_ARREADY;
  wire s00_couplers_to_s00_couplers_ARVALID;
  wire [31:0]s00_couplers_to_s00_couplers_AWADDR;
  wire s00_couplers_to_s00_couplers_AWREADY;
  wire s00_couplers_to_s00_couplers_AWVALID;
  wire s00_couplers_to_s00_couplers_BREADY;
  wire [1:0]s00_couplers_to_s00_couplers_BRESP;
  wire s00_couplers_to_s00_couplers_BVALID;
  wire [31:0]s00_couplers_to_s00_couplers_RDATA;
  wire s00_couplers_to_s00_couplers_RREADY;
  wire [1:0]s00_couplers_to_s00_couplers_RRESP;
  wire s00_couplers_to_s00_couplers_RVALID;
  wire [31:0]s00_couplers_to_s00_couplers_WDATA;
  wire s00_couplers_to_s00_couplers_WREADY;
  wire s00_couplers_to_s00_couplers_WVALID;

  assign M_AXI_araddr[31:0] = s00_couplers_to_s00_couplers_ARADDR;
  assign M_AXI_arvalid = s00_couplers_to_s00_couplers_ARVALID;
  assign M_AXI_awaddr[31:0] = s00_couplers_to_s00_couplers_AWADDR;
  assign M_AXI_awvalid = s00_couplers_to_s00_couplers_AWVALID;
  assign M_AXI_bready = s00_couplers_to_s00_couplers_BREADY;
  assign M_AXI_rready = s00_couplers_to_s00_couplers_RREADY;
  assign M_AXI_wdata[31:0] = s00_couplers_to_s00_couplers_WDATA;
  assign M_AXI_wvalid = s00_couplers_to_s00_couplers_WVALID;
  assign S_AXI_arready = s00_couplers_to_s00_couplers_ARREADY;
  assign S_AXI_awready = s00_couplers_to_s00_couplers_AWREADY;
  assign S_AXI_bresp[1:0] = s00_couplers_to_s00_couplers_BRESP;
  assign S_AXI_bvalid = s00_couplers_to_s00_couplers_BVALID;
  assign S_AXI_rdata[31:0] = s00_couplers_to_s00_couplers_RDATA;
  assign S_AXI_rresp[1:0] = s00_couplers_to_s00_couplers_RRESP;
  assign S_AXI_rvalid = s00_couplers_to_s00_couplers_RVALID;
  assign S_AXI_wready = s00_couplers_to_s00_couplers_WREADY;
  assign s00_couplers_to_s00_couplers_ARADDR = S_AXI_araddr[31:0];
  assign s00_couplers_to_s00_couplers_ARREADY = M_AXI_arready;
  assign s00_couplers_to_s00_couplers_ARVALID = S_AXI_arvalid;
  assign s00_couplers_to_s00_couplers_AWADDR = S_AXI_awaddr[31:0];
  assign s00_couplers_to_s00_couplers_AWREADY = M_AXI_awready;
  assign s00_couplers_to_s00_couplers_AWVALID = S_AXI_awvalid;
  assign s00_couplers_to_s00_couplers_BREADY = S_AXI_bready;
  assign s00_couplers_to_s00_couplers_BRESP = M_AXI_bresp[1:0];
  assign s00_couplers_to_s00_couplers_BVALID = M_AXI_bvalid;
  assign s00_couplers_to_s00_couplers_RDATA = M_AXI_rdata[31:0];
  assign s00_couplers_to_s00_couplers_RREADY = S_AXI_rready;
  assign s00_couplers_to_s00_couplers_RRESP = M_AXI_rresp[1:0];
  assign s00_couplers_to_s00_couplers_RVALID = M_AXI_rvalid;
  assign s00_couplers_to_s00_couplers_WDATA = S_AXI_wdata[31:0];
  assign s00_couplers_to_s00_couplers_WREADY = M_AXI_wready;
  assign s00_couplers_to_s00_couplers_WVALID = S_AXI_wvalid;
endmodule
