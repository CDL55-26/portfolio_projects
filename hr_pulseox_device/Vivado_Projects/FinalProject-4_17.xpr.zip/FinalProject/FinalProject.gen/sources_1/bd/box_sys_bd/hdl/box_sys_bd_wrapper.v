//Copyright 1986-2021 Xilinx, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2021.1 (win64) Build 3247384 Thu Jun 10 19:36:33 MDT 2021
//Date        : Thu Apr 17 00:25:17 2025
//Host        : P1-05 running 64-bit major release  (build 9200)
//Command     : generate_target box_sys_bd_wrapper.bd
//Design      : box_sys_bd_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module box_sys_bd_wrapper
   (clk_100MHz,
    reset_rtl_0,
    scl_0,
    sda_0);
  input clk_100MHz;
  input reset_rtl_0;
  inout scl_0;
  inout sda_0;

  wire clk_100MHz;
  wire reset_rtl_0;
  wire scl_0;
  wire sda_0;

  box_sys_bd box_sys_bd_i
       (.clk_100MHz(clk_100MHz),
        .reset_rtl_0(reset_rtl_0),
        .scl_0(scl_0),
        .sda_0(sda_0));
endmodule
