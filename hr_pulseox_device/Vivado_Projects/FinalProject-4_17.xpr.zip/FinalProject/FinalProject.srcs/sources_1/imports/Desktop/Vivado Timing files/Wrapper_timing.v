`timescale 1ns / 1ps
/**
 * 
 * This is the Wrapper module that will serve as the header file combining your processor, 
 * RegFile and Memory elements together.
 * 
 * You are allowed to make changes to the Wrapper files for your own individual testing, 
 * but we expect your final processor.v and memory modules to work with the provided Wrapper interface.
 * 
 **/

module Wrapper (
	input clock,
	input reset_rtl_0,

	// AXI-Lite master interface (to AXI IIC IP)
	output [31:0] s_axi_awaddr,
	output        s_axi_awvalid,
	input         s_axi_awready,

	output [31:0] s_axi_wdata,
	output        s_axi_wvalid,
	input         s_axi_wready,

	input  [1:0]  s_axi_bresp,
	input         s_axi_bvalid,
	output        s_axi_bready,

	output [31:0] s_axi_araddr,
	output        s_axi_arvalid,
	input         s_axi_arready,

	input  [31:0] s_axi_rdata,
	input  [1:0]  s_axi_rresp,
	input         s_axi_rvalid,
	output        s_axi_rready,

	// I2C physical lines
	inout scl,
	inout sda,

	// Exposed ports for IOBUF connections (from block design)
	output axi_iic_0_scl_i,
    output axi_iic_0_sda_i,
    
    // These are inputs coming from AXI IIC (they drive IOBUFs)
    input  axi_iic_0_scl_o,
    input  axi_iic_0_scl_t,
    input  axi_iic_0_sda_o,
    input  axi_iic_0_sda_t
);

	wire rwe, mwe;
	wire[4:0] rd, rs1, rs2;
	wire[31:0] instAddr, instData, 
		rData, regA, regB,
		memAddr, memDataIn, memDataOut;
	
	assign reset = ~reset_rtl_0;

	// IOBUFs to route bidirectional I2C lines to FPGA pins
	IOBUF scl_iobuf (
		.I(axi_iic_0_scl_o),
		.O(axi_iic_0_scl_i),
		.T(axi_iic_0_scl_t),
		.IO(scl)
	);

	IOBUF sda_iobuf (
		.I(axi_iic_0_sda_o),
		.O(axi_iic_0_sda_i),
		.T(axi_iic_0_sda_t),
		.IO(sda)
	);

	/*Wires for max Interface*/
	localparam MMREG = 5'd9;

	wire        axi_iic_valid;
	wire        axi_iic_write;
	wire        axi_iic_read;
	wire [7:0]  axi_iic_addr;
	wire [7:0]  axi_iic_wdata;
	wire [7:0]  axi_iic_rdata;
	wire        axi_iic_ready;

	wire [11:0]  interface_ram_addr;
	wire [31:0]  interface_ram_data;
	wire         interface_ram_we;

	wire         interface_busy;
	wire         data_ready;
	wire         start_signal;
	/*End Wires for max interface*/

	// ADD YOUR MEMORY FILE HERE
	localparam INSTR_FILE = "";

	// Main Processing Unit
	processor CPU(.clock(clock), .reset(reset),
		.address_imem(instAddr), .q_imem(instData),
		.ctrl_writeEnable(rwe), .ctrl_writeReg(rd),
		.ctrl_readRegA(rs1), .ctrl_readRegB(rs2), 
		.data_writeReg(rData), .data_readRegA(regA), .data_readRegB(regB),
		.wren(mwe), .address_dmem(memAddr), 
		.data(memDataIn), .q_dmem(memDataOut)); 

	// Instruction Memory (ROM)
	ROM #(.MEMFILE({INSTR_FILE, ".mem"}))
	InstMem(.clk(clock), 
		.addr(instAddr[11:0]), 
		.dataOut(instData));

	// Register File
	regfile RegisterFile(.clock(clock),
		.ctrl_writeEnable(data_ready ? 1'b1 : rwe), .ctrl_reset(reset), 
		.ctrl_writeReg(data_ready ? MMREG : rd),
		.ctrl_readRegA(rs1), .ctrl_readRegB(rs2), 
		.data_writeReg(data_ready ? 32'd1 : rData), 
		.data_readRegA(regA), .data_readRegB(regB));

	// Processor Memory (RAM)
	RAM ProcMem(.clk(clock), 
		.wEn(interface_busy ? interface_ram_we : mwe),
		.addr(interface_busy ? interface_ram_addr : memAddr[11:0]),
		.dataIn(interface_busy ? interface_ram_data : memDataIn), 
		.dataOut(memDataOut));

	// MAX30102 FSM Interface
	max30102_interface #(
		.ADDR_WIDTH(12),
		.DATA_WIDTH(32),
		.NUM_SAMPLES(1000)
	) max_if (
		.clk(clock),
		.rst(reset),
		.start(start_signal),
		.busy(interface_busy),
		.data_ready(data_ready),

		.axi_iic_valid (axi_iic_valid),
		.axi_iic_write (axi_iic_write),
		.axi_iic_read  (axi_iic_read),
		.axi_iic_addr  (axi_iic_addr),
		.axi_iic_wdata (axi_iic_wdata),
		.axi_iic_rdata (axi_iic_rdata),
		.axi_iic_ready (axi_iic_ready),

		.ram_addr  (interface_ram_addr),
		.ram_data  (interface_ram_data),
		.ram_we    (interface_ram_we)
	);

	// AXI-Lite Adapter
	axi_lite_iic_adapter #(
		.C_S_AXI_ADDR_WIDTH(32),
		.C_S_AXI_DATA_WIDTH(32),
		.IIC_BASE_ADDR(32'h44A00000)
	) axi_adapter (
		.clk(clock),
		.rst(reset),

		.axi_iic_valid (axi_iic_valid),
		.axi_iic_write (axi_iic_write),
		.axi_iic_read  (axi_iic_read),
		.axi_iic_addr  (axi_iic_addr),
		.axi_iic_wdata (axi_iic_wdata),
		.axi_iic_rdata (axi_iic_rdata),
		.axi_iic_ready (axi_iic_ready),

		.s_axi_awaddr  (s_axi_awaddr),
		.s_axi_awvalid (s_axi_awvalid),
		.s_axi_awready (s_axi_awready),

		.s_axi_wdata   (s_axi_wdata),
		.s_axi_wvalid  (s_axi_wvalid),
		.s_axi_wready  (s_axi_wready),

		.s_axi_bresp   (s_axi_bresp),
		.s_axi_bvalid  (s_axi_bvalid),
		.s_axi_bready  (s_axi_bready),

		.s_axi_araddr  (s_axi_araddr),
		.s_axi_arvalid (s_axi_arvalid),
		.s_axi_arready (s_axi_arready),

		.s_axi_rdata   (s_axi_rdata),
		.s_axi_rresp   (s_axi_rresp),
		.s_axi_rvalid  (s_axi_rvalid),
		.s_axi_rready  (s_axi_rready)
	);

endmodule
