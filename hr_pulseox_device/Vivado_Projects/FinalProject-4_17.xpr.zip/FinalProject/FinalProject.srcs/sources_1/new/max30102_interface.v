module max30102_interface #(
    parameter ADDR_WIDTH   = 10, //RAM address width
    parameter DATA_WIDTH   = 32, //write 32 bits at a time = 4 bytes = 1 word
    //each sample is 6 bytes, will want to write 3 bytes of red/ir data and bad with an empty byte (a waste :/ )
    parameter NUM_SAMPLES  = 1000 // 500 red, 500 IR
)(
    input  clk, //sys clock
    input  rst, //global reset
    input  start, //start flag fo setup + data read
    output reg busy, //shits going on
    output reg data_ready,

    output reg        axi_iic_valid, //not sure
    input             axi_iic_ready, //byte is ready to read?
    output reg [7:0]  axi_iic_addr, //register / device to write to
    output reg [7:0]  axi_iic_wdata, //data to write
    input      [7:0]  axi_iic_rdata, //data being read
    output reg        axi_iic_write, //1 if write
    output reg        axi_iic_read,  //1 if read

    output reg [ADDR_WIDTH-1:0] ram_addr, //address in RAM to write to
    output reg [DATA_WIDTH-1:0] ram_data, //data to write to ram
    output reg                  ram_we //ram write enable
);

    localparam [7:0]
        REG_FIFO_DATA   = 8'h07, //register names
        REG_MODE_CONFIG = 8'h09,
        REG_SPO2_CONFIG = 8'h0A,
        REG_LED1_PA     = 8'h0C,
        REG_LED2_PA     = 8'h0D;

    localparam SAMPLE_BYTES = 3; //bytes per Red or IR sample
    localparam CONFIG_NUM   = 4; //number of registers to configure, zero indexed 
    localparam IR_BASE      = 500;

    localparam [3:0] //states
        IDLE         = 4'd0,
        CONFIG_START = 4'd1,
        CONFIG_WRITE = 4'd2,
        CONFIG_WAIT  = 4'd3,
        CONFIG_DONE  = 4'd4,
        READ_FIFO    = 4'd5,
        READ_WAIT    = 4'd6,
        WRITE_RAM    = 4'd7,
        DONE         = 4'd8;

    reg [3:0] state, next_state;

    reg [2:0] config_index;
    reg [2:0] byte_count; //tracks bytes in a sample
    reg [$clog2(NUM_SAMPLES)-1:0] sample_index; //index for array of samples 

    reg [ADDR_WIDTH-1:0] red_ptr; //ptr for writing to RAM address
    reg [ADDR_WIDTH-1:0] IR_ptr;

    reg IR_active; //1 if red data being read, else 0

    reg [23:0] read_data_temp; //buffer for read data (3 bytes)-> RAM

    reg [7:0] config_addr [0:CONFIG_NUM-1]; //array of addresses for config
    reg [7:0] config_data [0:CONFIG_NUM-1]; //array of data to write for config
    integer i;

    initial begin //ROMish thing to keep track of config addresses and config data
        config_addr[0] = REG_MODE_CONFIG; config_data[0] = 8'h03;
        config_addr[1] = REG_SPO2_CONFIG; config_data[1] = 8'h27;
        config_addr[2] = REG_LED1_PA;     config_data[2] = 8'h24;
        config_addr[3] = REG_LED2_PA;     config_data[3] = 8'h24;
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin //global reset
            state         <= IDLE;
            config_index  <= 0; //index for rom block
            byte_count    <= 0; //number of bytes read
            sample_index  <= 0; //index for sample array
            red_ptr       <= 0; //points 0-499 for red data
            IR_ptr        <= IR_BASE; //points 500-999 for IR data
            IR_active     <= 0; //RAM will point to red region
            ram_we        <= 0; //ram write enable
            data_ready    <= 0; //data ready flag for processor, done with writing all samples
            axi_iic_valid <= 0; //need to review
            axi_iic_write <= 0;
            axi_iic_read  <= 0;
        end else begin
            state <= next_state; //update state only in sequential FSM, want switch to be clocked
            case (state)
                IDLE: begin
                    IR_active <= 0;
                    busy <= 0;
                    if (start) begin
                        config_index <= 0;
                        busy <= 1;
                    end
                end

                CONFIG_WAIT: begin
                    if (axi_iic_ready) //written data, waiting for i2c response, after response increase ROM index
                        config_index <= config_index + 1;
                end

                READ_WAIT: begin
                    if (axi_iic_ready) begin
                        read_data_temp <= {read_data_temp[15:0], axi_iic_rdata}; //left shift data to store 3 bytes
                        byte_count     <= byte_count + 1; //increment byte count -> heading towards 3
                    end
                end

                WRITE_RAM: begin
                    if (IR_active)
                        IR_ptr <= IR_ptr + 1; //increment RAM pointer 
                    else
                        red_ptr <= red_ptr + 1;

                    IR_active      <= ~IR_active; //toggle red active
                    byte_count     <= 0; //reset byte count to zero
                    read_data_temp <= 24'b0; //reset temp buffer
                    sample_index   <= sample_index + 1; //increase sample index -> heading towards 1000 now
                end

                DONE: begin
                    data_ready <= 1; //set global data ready flag high
                    busy <= 0; //turn off busy flag
                end

                default: begin
                    //spin, waiting for valid state for sequential logic
                end
            endcase
        end
    end

    always @(*) begin //default inputs
        next_state    = state;
        axi_iic_valid = 0;
        axi_iic_write = 0;
        axi_iic_read  = 0;
        axi_iic_addr  = 8'h00;
        axi_iic_wdata = 8'h00;
        ram_we        = 0;
        ram_data      = {DATA_WIDTH{1'b0}};
        ram_addr      = IR_active ? IR_ptr : red_ptr; //initialized to point to red

        case (state)
            IDLE: begin
                data_ready = 0;
                if (start)
                    next_state = CONFIG_START;
            end

            CONFIG_START: begin
                next_state = CONFIG_WRITE;
            end

            CONFIG_WRITE: begin 
                axi_iic_valid = 1;
                axi_iic_write = 1;
                axi_iic_addr  = config_addr[config_index]; //write data from ROM, stores register addresses + data to write
                axi_iic_wdata = config_data[config_index];
                next_state    = CONFIG_WAIT;
            end

            CONFIG_WAIT: begin
                if (axi_iic_ready) begin
                    if (config_index + 1 == CONFIG_NUM)
                        next_state = CONFIG_DONE;
                    else
                        next_state = CONFIG_WRITE; //keep cycling through states untill all write data has been written
                end
            end

            CONFIG_DONE: begin
                next_state = READ_FIFO;
            end

            READ_FIFO: begin
                axi_iic_valid = 1;
                axi_iic_read  = 1; //specify read from FIFO reg
                axi_iic_addr  = REG_FIFO_DATA;
                next_state    = READ_WAIT;
            end

            READ_WAIT: begin
                if (axi_iic_ready) //once byte transmitted, start RAM write
                    if (byte_count + 1 == SAMPLE_BYTES)
                        next_state = WRITE_RAM;
                    else
                        next_state = READ_FIFO;
            end

            WRITE_RAM: begin
                ram_we   = 1;
                ram_data = {8'd0, read_data_temp};
                if (sample_index + 1 == NUM_SAMPLES)
                    next_state = DONE;
                else
                    next_state = READ_FIFO;
            end

            DONE: begin
                if (!start)
                    next_state = IDLE;
            end

            default: next_state = IDLE;
        endcase
    end

endmodule