
module axi_lite_iic_adapter #(
    // Widths of the AXI?Lite interface
    parameter C_S_AXI_ADDR_WIDTH = 32,
    parameter C_S_AXI_DATA_WIDTH = 32,
    // Base address of the AXI IIC IP in your system's
    // memory map.  You'll get this from your Vivado block design.
    parameter IIC_BASE_ADDR      = 32'h44A0_0000
)(
    input  wire                        clk,
    input  wire                        rst,

    // --- FSM side (your max30102_interface) ---
    input  wire        axi_iic_valid,  // start a transaction
    input  wire        axi_iic_write,  // 1 = write, 0 = read
    input  wire        axi_iic_read,   // 1 = read,  0 = write
    input  wire [7:0]  axi_iic_addr,   // MAX30102 register address
    input  wire [7:0]  axi_iic_wdata,  // byte to write
    output reg  [7:0]  axi_iic_rdata,  // byte read
    output reg         axi_iic_ready,  // transaction complete

    // --- AXI?Lite master side (to the IIC IP) ---
    output reg  [C_S_AXI_ADDR_WIDTH-1:0] s_axi_awaddr,
    output reg                           s_axi_awvalid,
    input  wire                          s_axi_awready,
    output reg  [C_S_AXI_DATA_WIDTH-1:0] s_axi_wdata,
    output reg                           s_axi_wvalid,
    input  wire                          s_axi_wready,
    input  wire  [1:0]                   s_axi_bresp,
    input  wire                          s_axi_bvalid,
    output reg                           s_axi_bready,

    output reg  [C_S_AXI_ADDR_WIDTH-1:0] s_axi_araddr,
    output reg                           s_axi_arvalid,
    input  wire                          s_axi_arready,
    input  wire  [C_S_AXI_DATA_WIDTH-1:0] s_axi_rdata,
    input  wire  [1:0]                    s_axi_rresp,
    input  wire                          s_axi_rvalid,
    output reg                           s_axi_rready
);

    // State machine for AXI transactions
    localparam IDLE = 3'd0,
               AW   = 3'd1,  // address?write
               W    = 3'd2,  // data?write
               B    = 3'd3,  // write?response
               AR   = 3'd4,  // address?read
               R    = 3'd5;  // data?read

    reg [2:0] state, next_state;

    // Latch the FSM�s request on start
    reg        op_is_write;
    reg [31:0] target_addr;
    reg [31:0] write_data;

    // Capture FSM side inputs when valid
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state         <= IDLE;
            op_is_write   <= 1'b0;
            target_addr   <= 0;
            write_data    <= 0;
            axi_iic_ready <= 1'b0;
        end else begin
            state <= next_state;
            // When we see a new request in IDLE, latch it
            if (state == IDLE && axi_iic_valid) begin
                op_is_write   <= axi_iic_write;
                target_addr   <= IIC_BASE_ADDR 
                               + {24'd0, axi_iic_addr, 2'b00};  
                  // assumes your IP uses byte?addressed regs; adjust as needed
                write_data    <= {24'd0, axi_iic_wdata};
                axi_iic_ready <= 1'b0;
            end
            // When transaction completes, flag back to FSM
            if ((state == B    && s_axi_bvalid && s_axi_bready) ||
                (state == R    && s_axi_rvalid && s_axi_rready)) begin
                axi_iic_ready <= 1'b1;
                if (!op_is_write)
                    axi_iic_rdata <= s_axi_rdata[7:0];
            end
        end
    end

    // Next�state and AXI?Lite signal logic
    always @(*) begin
        // defaults
        next_state    = state;
        s_axi_awaddr  = 0;
        s_axi_awvalid = 0;
        s_axi_wdata   = 0;
        s_axi_wvalid  = 0;
        s_axi_bready  = 0;
        s_axi_araddr  = 0;
        s_axi_arvalid = 0;
        s_axi_rready  = 0;

        case (state)
            IDLE: begin
                if (axi_iic_valid) begin
                    if (op_is_write)
                        next_state = AW;
                    else
                        next_state = AR;
                end
            end

            //---- Write path ----
            AW: begin
                s_axi_awaddr  = target_addr;
                s_axi_awvalid = 1;
                if (s_axi_awready)
                    next_state = W;
            end

            W: begin
                s_axi_wdata  = write_data;
                s_axi_wvalid = 1;
                if (s_axi_wready)
                    next_state = B;
            end

            B: begin
                s_axi_bready = 1;
                if (s_axi_bvalid)
                    next_state = IDLE;
            end

            //---- Read path ----
            AR: begin
                s_axi_araddr  = target_addr;
                s_axi_arvalid = 1;
                if (s_axi_arready)
                    next_state = R;
            end

            R: begin
                s_axi_rready = 1;
                if (s_axi_rvalid)
                    next_state = IDLE;
            end

            default: next_state = IDLE;
        endcase
    end

endmodule