
module axi_lite_iic_adapter #(
    parameter C_S_AXI_ADDR_WIDTH = 32,
    parameter C_S_AXI_DATA_WIDTH = 32,
    parameter IIC_BASE_ADDR      = 32'h44A0_0000
)(
    input  wire                           clk,
    input  wire                           rst,

    // Simplified request from sensor-FSM
    input  wire        req_valid,
    input  wire        req_write,           // 1 = write, 0 = read
    input  wire [7:0]  req_addr,            // MAX30102 register
    input  wire [7:0]  req_wdata,
    output reg  [7:0]  resp_rdata,
    output reg         resp_ready,          // 1-clk pulse when done

    // AXI-Lite master interface to AXI IIC IP
    output reg  [C_S_AXI_ADDR_WIDTH-1:0] m_awaddr,
    output reg                           m_awvalid,
    input  wire                          m_awready,

    output reg  [C_S_AXI_DATA_WIDTH-1:0] m_wdata,
    output reg                           m_wvalid,
    input  wire                          m_wready,

    input  wire  [1:0]                   m_bresp,
    input  wire                          m_bvalid,
    output reg                           m_bready,

    output reg  [C_S_AXI_ADDR_WIDTH-1:0] m_araddr,
    output reg                           m_arvalid,
    input  wire                          m_arready,

    input  wire  [C_S_AXI_DATA_WIDTH-1:0] m_rdata,
    input  wire  [1:0]                    m_rresp,
    input  wire                          m_rvalid,
    output reg                           m_rready
);
    //------------------------------------------------------------------
    //  Local parameters
    //------------------------------------------------------------------
    localparam CR_OFF      = 32'h100,
               SR_OFF      = 32'h104,
               TXFIFO_OFF  = 32'h108,
               RXFIFO_OFF  = 32'h10C;

    // main FSM states
    localparam S_IDLE   = 4'd0,
               S_WAIT_BNB = 4'd1,
               S_PUSH_AW  = 4'd2,
               S_PUSH_W   = 4'd3,
               S_PUSH_B   = 4'd4,
               S_START    = 4'd5,
               S_POLL_SR  = 4'd6,
               S_READ_BYTE= 4'd7,
               S_DONE     = 4'd8;

    reg [3:0] state, n_state;

    // internal working regs
    reg [7:0] lat_reg;      // register address
    reg [7:0] lat_wdata;    // data to write
    reg       lat_is_wr;    // 1=write, 0=read

    //------------------------------------------------------------------
    //  AXI Lite single-beat write helper
    //------------------------------------------------------------------
    reg do_aw, do_w, do_ar;      // one-cycle strobes from state logic
    reg [31:0] aw_addr, ar_addr, w_data;

    // Generate AXI-Lite address & data channels
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            m_awvalid <= 0; m_wvalid <= 0; m_arvalid <= 0;
            m_awaddr  <= 0; m_wdata  <= 0; m_araddr  <= 0;
        end else begin
            // AW
            if (!m_awvalid || m_awready) begin
                m_awvalid <= do_aw;
            end
            if (do_aw)  m_awaddr <= aw_addr;

            // W
            if (!m_wvalid || m_wready) begin
                m_wvalid <= do_w;
            end
            if (do_w)   m_wdata  <= w_data;

            // AR
            if (!m_arvalid || m_arready) begin
                m_arvalid <= do_ar;
            end
            if (do_ar)  m_araddr <= ar_addr;
        end
    end

    // BRESP / RRESP handshake
    always @(posedge clk or posedge rst) begin
        if (rst) begin m_bready <= 0; m_rready <= 0; end
        else begin
            // write response: ack immediately when valid
            m_bready <= m_bvalid;
            // read response: accept when state requests
            m_rready <= (state == S_READ_BYTE);
        end
    end

    //------------------------------------------------------------------
    //  High-level FSM - one byte op
    //------------------------------------------------------------------
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state <= S_IDLE; resp_ready <= 0;
            lat_reg <= 0; lat_wdata <= 0; lat_is_wr <= 0; resp_rdata <= 0;
        end else begin
            state <= n_state;
            // pulse ready low by default
            resp_ready <= (n_state == S_DONE);
            // capture request once
            if (state == S_IDLE && req_valid) begin
                lat_reg    <= req_addr;
                lat_wdata  <= req_wdata;
                lat_is_wr  <= req_write;
            end
            // grab read data when it comes
            if (state == S_READ_BYTE && m_rvalid) begin
                resp_rdata <= m_rdata[7:0];
            end
        end
    end

    //------------------------------------------------------------------
    //  Combinational next-state & AXI command generation
    //------------------------------------------------------------------
    always @(*) begin
        // default outputs
        n_state  = state;
        do_aw    = 0; do_w = 0; do_ar = 0;
        aw_addr  = 0; ar_addr = 0; w_data = 0;

        case (state)
            // Wait here until a new op requested
            S_IDLE: begin
                if (req_valid) n_state = S_WAIT_BNB;
            end
            // Poll Status[4] Bus Not Busy before starting
            S_WAIT_BNB: begin
                // issue AR to SR once
                do_ar   = 1; ar_addr = IIC_BASE_ADDR + SR_OFF;
                if (m_arready) n_state = S_POLL_SR;  // use same state to read value
            end
            S_POLL_SR: begin
                if (m_rvalid) begin
                    if (m_rdata[4]) n_state = S_PUSH_AW; // bus free
                    else           n_state = S_WAIT_BNB; // loop again
                end
            end
            // Push 1st byte: slave address + W (always start with write)
            S_PUSH_AW: begin
                do_aw   = 1; aw_addr = IIC_BASE_ADDR + TXFIFO_OFF;
                do_w    = 1; w_data  = {24'h0, 8'hAE}; // 0x57 <<1 | 0
                if (m_wready) n_state = S_PUSH_W;
            end
            // Push register addr
            S_PUSH_W: begin
                do_aw   = 1; aw_addr = IIC_BASE_ADDR + TXFIFO_OFF;
                do_w    = 1; w_data  = {24'h0, lat_reg};
                if (m_wready) begin
                    if (lat_is_wr) n_state = S_PUSH_B; // need data byte
                    else          n_state = S_START;   // go to repeated start
                end
            end
            // Push data byte (write op only)
            S_PUSH_B: begin
                do_aw   = 1; aw_addr = IIC_BASE_ADDR + TXFIFO_OFF;
                do_w    = 1; w_data  = {24'h0, lat_wdata};
                if (m_wready) n_state = S_START;
            end
            // Write CR to set EN|MSMS
            S_START: begin
                do_aw   = 1; aw_addr = IIC_BASE_ADDR + CR_OFF;
                do_w    = 1; w_data  = 32'h0000_00C2;  // EN(0)=1, MSMS(6)=1, TX_FIFO_RST(2)=0
                if (m_wready) begin
                    if (lat_is_wr) n_state = S_POLL_SR; // wait for bus free then done
                    else          n_state = S_READ_BYTE; // need to read back after second start (not implemented fully)
                end
            end
            // Wait for SR[4]=1 and TX FIFO empty before finishing
            S_READ_BYTE: begin
                // *** Placeholder for read sequence (repeat-start not shown here) ***
                // For brevity, we'll skip read support in this minimal version.
                n_state = S_DONE;
            end
            S_DONE: n_state = S_IDLE;
            default: n_state = S_IDLE;
        endcase
    end
endmodule
