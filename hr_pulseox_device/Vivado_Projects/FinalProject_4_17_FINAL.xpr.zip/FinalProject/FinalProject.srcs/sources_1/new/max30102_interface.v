`timescale 1ns / 1ps
module max30102_interface #(
    parameter ADDR_WIDTH  = 12,
    parameter DATA_WIDTH  = 32,
    parameter NUM_SAMPLES = 1000
)(
    input  wire                    clk,
    input  wire                    rst,
    input  wire                    start,
    output reg                     busy,
    output reg                     data_ready,

    // updated handshake ? AXI-Lite adapter
    output reg                     req_valid,
    input  wire                    resp_ready,
    output reg  [7:0]              req_addr,
    output reg  [7:0]              req_wdata,
    input  wire  [7:0]             resp_rdata,
    output reg                     req_write,

    // RAM port
    output reg [ADDR_WIDTH-1:0]    ram_addr,
    output reg [DATA_WIDTH-1:0]    ram_data,
    output reg                     ram_we,

    // debug LEDs
    output wire [15:0]             LED
);
//------------------------------------------------------------
//  Local parameters and small ROM for config sequence
//------------------------------------------------------------
localparam REG_FIFO_WR_PTR = 8'h04;
localparam REG_FIFO_RD_PTR = 8'h06;
localparam REG_FIFO_DATA   = 8'h07;
localparam REG_MODE_CONFIG = 8'h09;
localparam REG_SPO2_CONFIG = 8'h0A;
localparam REG_LED1_PA     = 8'h0C;
localparam REG_LED2_PA     = 8'h0D;

localparam SAMPLE_BYTES = 3;
localparam CFG_COUNT    = 6;     // 4 user cfg + 2 FIFO reset

reg [7:0] cfg_addr [0:CFG_COUNT-1];
reg [7:0] cfg_data [0:CFG_COUNT-1];
initial begin
    cfg_addr[0] = REG_MODE_CONFIG; cfg_data[0] = 8'h03;  // SpO2
    cfg_addr[1] = REG_SPO2_CONFIG; cfg_data[1] = 8'h27;  // 100?sps, 18-bit
    cfg_addr[2] = REG_LED1_PA;     cfg_data[2] = 8'h24;
    cfg_addr[3] = REG_LED2_PA;     cfg_data[3] = 8'h24;
    cfg_addr[4] = REG_FIFO_WR_PTR; cfg_data[4] = 8'h00;  // clear FIFO
    cfg_addr[5] = REG_FIFO_RD_PTR; cfg_data[5] = 8'h00;
end

localparam [3:0] S_IDLE=0,S_CFG=1,S_CFG_WAIT=2,S_CFG_NEXT=3,
                 S_RD=4,S_RD_WAIT=5,S_STORE=6,S_DONE=7;

localparam ADDR_W = $clog2(NUM_SAMPLES);

reg [3:0] state;
reg [2:0] cfg_idx;
reg [1:0] byte_cnt;
reg [ADDR_W-1:0] sample_cnt;
reg [23:0] shreg;

assign LED = {11'd0,state,resp_ready,start};

always @(posedge clk or posedge rst) begin
    if (rst) begin
        state<=S_IDLE;busy<=0;data_ready<=0;req_valid<=0;req_write<=0;
        ram_we<=0;ram_addr<=0;ram_data<=0;cfg_idx<=0;byte_cnt<=0;sample_cnt<=0;shreg<=0;
    end else begin
        // defaults each cycle
        ram_we<=0;

        case(state)
        S_IDLE: begin
            data_ready<=0;busy<=0;req_valid<=0;
            if(start) begin
                busy<=1;cfg_idx<=0;req_valid<=1;req_write<=1;
                req_addr<=cfg_addr[0];req_wdata<=cfg_data[0];state<=S_CFG_WAIT;
            end
        end

        S_CFG_WAIT: begin
            if(resp_ready) begin
                req_valid<=0;           // drop VALID *after* READY
                state<=S_CFG_NEXT;
            end
        end

        S_CFG_NEXT: begin
            if(cfg_idx==CFG_COUNT-1) begin
                // start first FIFO read
                byte_cnt<=0;req_valid<=1;req_write<=0;req_addr<=REG_FIFO_DATA;
                state<=S_RD_WAIT;
            end else begin
                cfg_idx<=cfg_idx+1;req_valid<=1;req_write<=1;
                req_addr<=cfg_addr[cfg_idx+1];req_wdata<=cfg_data[cfg_idx+1];state<=S_CFG_WAIT;
            end
        end

        S_RD_WAIT: begin
            if(resp_ready) begin
                req_valid<=0;
                shreg<={shreg[15:0],resp_rdata};
                if(byte_cnt==SAMPLE_BYTES-1) begin
                    state<=S_STORE;
                end else begin
                    byte_cnt<=byte_cnt+1;req_valid<=1; // next byte
                end
            end
        end

        S_STORE: begin
            ram_we<=1;ram_addr<=sample_cnt;ram_data<={8'd0,shreg};
            sample_cnt<=sample_cnt+1;shreg<=0;byte_cnt<=0;
            if(sample_cnt==NUM_SAMPLES-1) state<=S_DONE;
            else begin
                req_valid<=1;req_write<=0;state<=S_RD_WAIT;
            end
        end

        S_DONE: begin
            busy<=0;data_ready<=1;
            if(~start) state<=S_IDLE;
        end
        default: state<=S_IDLE;
        endcase
    end
end
endmodule