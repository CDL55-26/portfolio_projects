`timescale 1ns / 1ps
// =============================================================================
//  Nexys-A7 "Wrapper" - CPU + MAX30102 + AXI-IIC
//  * Board 100-MHz clock is converted to 25 MHz by clk_wiz_0
//  * Active-HIGH push-button reset (BTN_C) is inverted internally
//  * I�C lines go through IOBUFs
// =============================================================================
module Wrapper_timing
(
    input  wire clk_100mhz,     // E3 on Nexys-A7
    input  wire reset_rtl_0,    // BTN_C  (active-HIGH on board)
    input  wire start_0,        // BTN_U  (start sensor capture)

    output wire [15:0] LED,

    inout  wire scl,            // JA1  - I�C clock
    inout  wire sda             // JA2  - I�C data
);

// DEBUG
assign LED = interface_LED;

// -----------------------------------------------------------------------------
// 1. Clock generation : 100 MHz ? 25 MHz
// -----------------------------------------------------------------------------
wire clk25;           // 25-MHz clock used by *all* logic below
wire pll_locked;

clk_wiz_0 u_clk_wiz
(
    .clk_in1     (clk_100mhz),
    .reset       (reset_rtl_0),
    .clk_out1    (clk25),
    .locked      (pll_locked)
);

reg [3:0] rst_sync = 4'b1111;
always @(posedge clk25 or posedge reset_rtl_0)
    if (reset_rtl_0)
        rst_sync <= 4'b1111;
    else
        rst_sync <= {rst_sync[2:0], ~pll_locked};

wire reset = reset_rtl_0;
wire reset_n = ~reset;

// -----------------------------------------------------------------------------
// 2. CPU / memories (unchanged except clock name)
// -----------------------------------------------------------------------------
localparam MMREG      = 5'd9;
localparam INSTR_FILE = "";

wire         rwe, mwe;
wire  [4:0]  rd, rs1, rs2;
wire [31:0]  instAddr, instData;
wire [31:0]  rData,     regA, regB;
wire [31:0]  memAddr,   memDataIn, memDataOut;

processor CPU (
    .clock           (clk25),
    .reset           (reset),
    .address_imem    (instAddr),
    .q_imem          (instData),
    .ctrl_writeEnable(rwe),
    .ctrl_writeReg   (rd),
    .ctrl_readRegA   (rs1),
    .ctrl_readRegB   (rs2),
    .data_writeReg   (rData),
    .data_readRegA   (regA),
    .data_readRegB   (regB),
    .wren            (mwe),
    .address_dmem    (memAddr),
    .data            (memDataIn),
    .q_dmem          (memDataOut)
);

ROM #(.MEMFILE({INSTR_FILE,".mem"})) InstMem (
    .clk    (clk25),
    .addr   (instAddr[11:0]),
    .dataOut(instData)
);

regfile RegisterFile (
    .clock            (clk25),
    .ctrl_writeEnable (data_ready ? 1'b1 : rwe),
    .ctrl_reset       (reset),
    .ctrl_writeReg    (data_ready ? MMREG : rd),
    .ctrl_readRegA    (rs1),
    .ctrl_readRegB    (rs2),
    .data_writeReg    (data_ready ? 32'd1 : rData),
    .data_readRegA    (regA),
    .data_readRegB    (regB)
);

RAM ProcMem (
    .clk    (clk25),
    .wEn    (interface_busy ? interface_ram_we : mwe),
    .addr   (interface_busy ? interface_ram_addr : memAddr[11:0]),
    .dataIn (interface_busy ? interface_ram_data : memDataIn),
    .dataOut(memDataOut)
);

// -----------------------------------------------------------------------------
// 3. MAX30102 FSM
// -----------------------------------------------------------------------------
wire         interface_busy, data_ready;
wire [11:0]  interface_ram_addr;
wire [31:0]  interface_ram_data;
wire         interface_ram_we;

wire         req_valid, req_write;
wire  [7:0]  req_addr, req_wdata;
wire  [7:0]  resp_rdata;
wire         resp_ready;

wire [15:0] interface_LED;

max30102_interface #(
    .ADDR_WIDTH (12),
    .DATA_WIDTH (32),
    .NUM_SAMPLES(1000)
) max_if (
    .clk          (clk25),
    .rst          (reset),
    .start        (start_0),
    .busy         (interface_busy),
    .data_ready   (data_ready),

    .req_valid    (req_valid),
    .req_write    (req_write),
    .req_addr     (req_addr),
    .req_wdata    (req_wdata),
    .resp_rdata   (resp_rdata),
    .resp_ready   (resp_ready),

    .ram_addr     (interface_ram_addr),
    .ram_data     (interface_ram_data),
    .ram_we       (interface_ram_we),
    .LED          (interface_LED)
);

// -----------------------------------------------------------------------------
// 4. AXI-Lite adapter  (register-style ? AXI4-Lite)
// -----------------------------------------------------------------------------
wire [31:0] s_axi_awaddr, s_axi_wdata, s_axi_araddr, s_axi_rdata;
wire        s_axi_awvalid, s_axi_wvalid, s_axi_arvalid;
wire        s_axi_awready, s_axi_wready, s_axi_arready;
wire  [1:0] s_axi_bresp,   s_axi_rresp;
wire        s_axi_bvalid,  s_axi_bready, s_axi_rvalid, s_axi_rready;

axi_lite_iic_adapter #(
    .C_S_AXI_ADDR_WIDTH(32),
    .C_S_AXI_DATA_WIDTH(32),
    .IIC_BASE_ADDR     (32'h0000_0000)
) adapter (
    .clk          (clk25),
    .rst          (reset),

    .req_valid    (req_valid),
    .req_write    (req_write),
    .req_addr     (req_addr),
    .req_wdata    (req_wdata),
    .resp_rdata   (resp_rdata),
    .resp_ready   (resp_ready),

    .m_awaddr     (s_axi_awaddr),
    .m_awvalid    (s_axi_awvalid),
    .m_awready    (s_axi_awready),

    .m_wdata      (s_axi_wdata),
    .m_wvalid     (s_axi_wvalid),
    .m_wready     (s_axi_wready),

    .m_bresp      (s_axi_bresp),
    .m_bvalid     (s_axi_bvalid),
    .m_bready     (s_axi_bready),

    .m_araddr     (s_axi_araddr),
    .m_arvalid    (s_axi_arvalid),
    .m_arready    (s_axi_arready),

    .m_rdata      (s_axi_rdata),
    .m_rresp      (s_axi_rresp),
    .m_rvalid     (s_axi_rvalid),
    .m_rready     (s_axi_rready)
);

// -----------------------------------------------------------------------------
// 5. AXI-IIC IP core (v2.1)
// -----------------------------------------------------------------------------
wire [8:0] iic_awaddr = s_axi_awaddr[8:0];
wire [8:0] iic_araddr = s_axi_araddr[8:0];

wire axi_iic_0_scl_i, axi_iic_0_scl_o, axi_iic_0_scl_t;
wire axi_iic_0_sda_i, axi_iic_0_sda_o, axi_iic_0_sda_t;

axi_iic_0 iic_core (
    .s_axi_aclk   (clk25),
    .s_axi_aresetn(reset_n),

    .s_axi_awaddr (iic_awaddr),
    .s_axi_awvalid(s_axi_awvalid),
    .s_axi_awready(s_axi_awready),

    .s_axi_wdata  (s_axi_wdata),
    .s_axi_wvalid (s_axi_wvalid),
    .s_axi_wready (s_axi_wready),

    .s_axi_bresp  (s_axi_bresp),
    .s_axi_bvalid (s_axi_bvalid),
    .s_axi_bready (s_axi_bready),

    .s_axi_araddr (iic_araddr),
    .s_axi_arvalid(s_axi_arvalid),
    .s_axi_arready(s_axi_arready),

    .s_axi_rdata  (s_axi_rdata),
    .s_axi_rresp  (s_axi_rresp),
    .s_axi_rvalid (s_axi_rvalid),
    .s_axi_rready (s_axi_rready),

    .scl_i (axi_iic_0_scl_i),
    .scl_o (axi_iic_0_scl_o),
    .scl_t (axi_iic_0_scl_t),

    .sda_i (axi_iic_0_sda_i),
    .sda_o (axi_iic_0_sda_o),
    .sda_t (axi_iic_0_sda_t),

    .iic2intc_irpt()
);

// -----------------------------------------------------------------------------
// 6. IOBUFs for bidirectional SCL / SDA lines
// -----------------------------------------------------------------------------
IOBUF scl_iobuf (
    .I (axi_iic_0_scl_o),
    .O (axi_iic_0_scl_i),
    .T (axi_iic_0_scl_t),
    .IO(scl)
);

IOBUF sda_iobuf (
    .I (axi_iic_0_sda_o),
    .O (axi_iic_0_sda_i),
    .T (axi_iic_0_sda_t),
    .IO(sda)
);

endmodule
